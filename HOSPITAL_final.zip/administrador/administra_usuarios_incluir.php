<?php
// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=8; charset=iso-8859-1"/>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" type="text/css" href="../funcoes/css/style_contspi.css">
	<link rel="stylesheet" type="text/css" href="../funcoes/css/style_thin.jquery.dataTables.min.css">
	<script type="text/javascript" language="javascript" src="../funcoes/js/jquery-1.12.3.min.js"></script>
	<script type="text/javascript" language="javascript" src="../funcoes/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" class="init">
		$(document).ready(function() {
			$('#example').DataTable( {
			} );
		} );
	
    </script>
    <script type='text/javascript'>
		function validar_inclusao_usu() {
		if(document.novo_usuario.nome.value=="") {
		alert("O preenchimento do campo \"Nome\" � obrigat�rio");
		return false; // anulando o envio
		}
		if(document.novo_usuario.usuario.value=="") {
		alert("O preenchimento do campo \"Usu�rio\" � obrigat�rio");
		return false; // anulando o envio
		}
		else {
		return true; // envia
		}
		}
    </script>
	<style>
	body {
	font-family: Trebuchet MS, Arial, Helvetica, sans-serif;
	font-size: 11px;
	background: none;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 5px;
	margin-bottom: 5px;
	}
	table.dataTable.hover tbody tr:hover,table.dataTable.display tbody tr:hover{
	background-color:#FFF;
	}
    </style>
</head>
<body>
     <?php
	// ACENTUA��O DA P�GINA
	header('Content-Type: text/html; charset=ISO-8859-1');

 	require('../funcoes/criarCombo.php'); //Fun��o de convers�o de data para dd/mm/aaaa
	include "../funcoes/conecta_mysql.inc"; //Faz a conex�o com o banco de dados
	?>
<form method="GET" name="novo_usuario" action="administra_usuarios_incluir_db.php" autocomplete="off" onsubmit="return validar_inclusao_usu()">
    </td>
<table width="350" border="0" cellpadding="2" cellspacing="1" style="color:#69C; background-color: #eee; table.dataTable.hover tbody tr:hover,table.dataTable.display tbody tr:hover{ background-color:#FFF; }" id="example" class="display">
  <tr>
    <td width="100" style="background-color: white;">&nbsp;Nome</td>
    <td style="background-color: white;"><input name="Nome" id="Nome" type="text" style="width:250px; border: none;">
  </tr>
    <td style="background-color: white;">&nbsp;Login</td>
    <td style="background-color: white;"><input name="Login" type="text" style="width:250px; border: none;"></td>
  </tr>
  <td style="background-color: white;">&nbsp;Coren</td>
    <td style="background-color: white;"><input name="Coren" type="text" style="width:250px; border: none;"></td>
  </tr>
  <td style="background-color: white;">&nbsp;Categoria</td>
    <td style="background-color: white;"><input name="Categoria" type="text" style="width:250px; border: none;"></td>
  </tr>
  <td style="background-color: white;">&nbsp;Referencia</td>
    <td style="background-color: white;"><input name="Referencia" type="text" style="width:250px; border: none;"></td>
  </tr>
  <td style="background-color: white;">&nbsp;Vinculo</td>
    <td style="background-color: white;"><input name="Vinculo" type="text" style="width:250px; border: none;"></td>
  </tr>
   <td style="background-color: white;">&nbsp;Setor</td>
    <td style="background-color: white;"><input name="Nome_setor" type="text" style="width:250px; border: none;"></td>
  </tr>
  <tr align="center">
    <td colspan="2" style="background-color: white;" align="right">
    <input name="enviar" type="submit"  title="Click aqui para inserir um novo usu�rio" value="Cadastrar Usu�rio" style="vertical-align:middle;">
    <button type="reset" title="Limpar itens selecionados" onClick="verificaComboReset(this)" style="vertical-align:middle">Limpar</button>
    </td>
  </tr>
</table>
</form>
</body>