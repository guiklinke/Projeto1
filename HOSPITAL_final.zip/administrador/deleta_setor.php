
<?php
session_start();
 include "../funcoes/conecta_mysql.inc";


$setor = filter_input(INPUT_POST, 'setor', FILTER_SANITIZE_NUMBER_INT);

$alter_query = "UPDATE usuarios SET setor_ID = NULL WHERE setor_ID = '$setor'";
$a_query = "UPDATE usuarios_escalas SET setor_ID = NULL WHERE setor_ID = '$setor'";


$result_hosp = "DELETE FROM setores WHERE setor_ID= '$setor'";

$resultado_hosp = mysql_query($result_hosp,$conexao1);

if (mysql_affected_rows($conexao1)>0) {
  
  $_SESSION['msg'] = "<p style= color:blue;'>DELETADO COM SUCESSO!! </p>";
  header ("Location: setor_del.php");
} else {
  $_SESSION['msg'] = "<p style= color:red;'>NÃO DELETADO!!</p>";
  header ("Location: setor_del.php");
  
}

?>
