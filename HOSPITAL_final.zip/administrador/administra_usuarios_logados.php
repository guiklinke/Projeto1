<?php
// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" type="text/css" href="../funcoes/css/style_contspi.css">
	<link rel="stylesheet" type="text/css" href="../funcoes/css/style_thin.jquery.dataTables.min.css">
	<style type="text/css" class="init">
    h1,h2,h3,h4,h5,h6 {
    font-family: 'Lato', Calibri, Arial, sans-serif;
	}
    body {
	margin-left: 0px;
	margin-right: 0px;
	margin-top: 0px;
	background: none;
	}
    </style>
	<script type="text/javascript" language="javascript" src="../funcoes/js/jquery-1.12.0.min.js"></script>
	<script type="text/javascript" language="javascript" src="../funcoes/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" class="init">
	$(document).ready(function() {
		$('table.display').dataTable( {
		dom: 'Bfrtip',
		"lengthMenu": [[10], [10]],
        "info":     false,
		"ordering":       false,
		"language": {
        "sEmptyTable": "Nenhum registro encontrado",
		"sInfo": "Mostrando de _START_ at� _END_ de _TOTAL_ registros",
		"sInfoEmpty": "Mostrando 0 at� 0 de 0 registros",
		"sInfoFiltered": "(Filtrados de _MAX_ registros)",
		"sInfoPostFix": "",
		"sInfoThousands": ".",
		"sLengthMenu": "_MENU_ resultados por p�gina",
		"sLoadingRecords": "Carregando...",
		"sProcessing": "Processando...",
		"sZeroRecords": "Nenhum registro encontrado",
		"sSearch": "Pesquisar",
		"oPaginate": {
        "sNext": "Pr�ximo",
        "sPrevious": "Anterior",
        "sFirst": "Primeiro",
        "sLast": "�ltimo"
        }
		}
			} );
	} );
	</script>
	<script language="Javascript">
    function confirma()
            {
                    var resp = confirm('Clique em "OK" para excluir');
                    if (resp){
                    return true;
                    }
                    else{
                    return false;
                            }
    }
    </script>        
</head>
<body>
<?php
	// ACENTUA��O DA P�GINA
	header('Content-Type: text/html; charset=ISO-8859-1');
	date_default_timezone_set('America/Sao_Paulo');

	require('../funcoes/criarCombo.php'); //Fun��o de convers�o de data para dd/mm/aaaa
	include "../funcoes/conecta_mysql.inc";
 
 //INICIA AS VARIAVEIS DE ANO E MES 
	$ano_atual = date("Y");
	$dataAtual = date("d-m-Y");
	$dataAtualmod = date("Y-m-d");
	?>
<table cellspacing="0" cellpadding="0" width="480" style="padding:1em;  border: #eee solid 1px;" align="right">
<tr>
<td>
	<?php
	
$sql = "SELECT hospital.usuarios.*, hospital.usuarios_nivel.* FROM hospital.usuarios INNER JOIN hospital.usuarios_nivel ON hospital.usuarios_nivel.id_nivel = hospital.usuarios.nivel ORDER BY ID";
    $i = 1;
    $res=mysql_query($sql);
	$num_rows = mysql_num_rows($res);
	?>
<table id="example" class="display" cellspacing="0" cellpadding="0" width="470" align="center">
  <thead>
    <tr style="color:#F93;">
      <td colspan="8" style="border:none;font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:12px; text-transform:uppercase;">Usuarios Logados&nbsp;&nbsp;(<?php echo "$num_rows"; ?>)</td>
    </tr>
    <tr align="center" style="color:#69C;">
      <td >Nome</td>
      <td width="80">Login</td>
      <td width="60">Entrada</td>
      <td width="60">Hora</td>
      </tr>
    </thead>
    <?php
	while($row=mysql_fetch_array($res))
	{
	?>
		<tr align="center" style="cursor:pointer; text-transform: uppercase;">
		  <td style="color:<?php echo $cor_usuario; ?>" title="<?php echo $row[9]; ?>"><?php echo $row[1]; ?></td>
        
		<td><?php echo $row['Login']; ?></td>       
        <td style="color:#93F"><?php if($row['entrada']>0) echo formataDataHora($row['entrada'],"d-m-Y"); ?></td>
        <td style="color:#f93"><?php echo $row['hora_entrada']; ?></td>
        </tr>
        <?php } ?>
    </table>
</td>
</tr>
</table>    
</body>
</html>
