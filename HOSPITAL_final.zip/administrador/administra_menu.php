<?php
// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 
?>
        <!DOCTYPE HTML>
        <html>
        <head>
        <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
        <meta http-equiv="X-UA-Compatible" content="IE=8; charset=iso-8859-1"/>
		<link rel="stylesheet" type="text/css" href="../funcoes/css/style_menu.css">
		<style type="text/css">
        body {
            margin-top: 2px;
            margin-left: 0px;
            background: none;
        }
        </style>
</head>
<body>

<?php
include "../funcoes/conecta_mysql.inc"; # conex�o com o banco de dados
?>

<table align="left" cellpadding="0" cellspacing="0" style="padding-left:20px;">
<tr>
<td width="180" style="border:none; color:#f90; font-size:14px; vertical-align:middle;">MENU ADMINISTRA��O</td>
<td>
    <button class="btn_cinza_escuro" onClick="window.open('administra_usuarios_listar.php','mainFrameDoc')"><img src="../imagens/users.png" width="13" height="13" style="vertical-align:middle; border:none;"><span style="vertical-align: middle">&nbsp;Usu�rios&nbsp;</span>
	</button>
</td>

<td>
    <button class="btn_cinza_escuro" onClick="window.open('setores.php','mainFrameDoc')"><span style="vertical-align: middle">&nbsp;Cadastrar Setor&nbsp;</span></button>
</td>


<td>
    <button class="btn_cinza_escuro" onClick="window.open('setor_del.php','mainFrameDoc')"><span style="vertical-align: middle">&nbsp;Deletar Setor&nbsp;</span></button>
</td>

</tr>    
</table>
</body>
</html>

