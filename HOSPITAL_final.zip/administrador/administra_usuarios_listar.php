<?php

			

// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
	<link rel="stylesheet" type="text/css" href="../funcoes/css/style_contspi.css">
	<link rel="stylesheet" type="text/css" href="../funcoes/css/style_thin.jquery.dataTables.min.css">
	<style type="text/css" class="init">
	/* Ensure that the demo table scrolls 
	th, td { white-space: nowrap; }
	div.dataTables_wrapper {
		width: 100%;
		margin: 0 auto;
	}
                            */
	body {
	margin-top: 10px;
	background: none;
	}
    </style>
	<script type="text/javascript" language="javascript" src="../funcoes/js/jquery-1.12.3.min.js"></script>
	<script type="text/javascript" language="javascript" src="../funcoes/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="../funcoes/js/ajax.js"></script>
    <script type="text/javascript" language="javascript" src="administra_usuarios.js"></script>
	<script type="text/javascript" language="javascript" class="init">
	$(document).ready(function() {
		$('table.display').dataTable( {
		dom: 'Bfrtip',
		"lengthMenu": [[10], [10]],
		/*"sPaginationType": "full_numbers",
        "info":     false,*/
		"ordering":       false,
		"language": {
        "sEmptyTable": "Nenhum registro encontrado",
		"sInfo": "Mostrando de _START_ at� _END_ de _TOTAL_ Usu�rios",
		"sInfoEmpty": "Mostrando 0 at� 0 de 0 registros",
		"sInfoFiltered": "(Filtrados de _MAX_ registros)",
		"sInfoPostFix": "",
		"sInfoThousands": ".",
		"sLengthMenu": "_MENU_ Resultados por p�gina",
		"sLoadingRecords": "Carregando...",
		"sProcessing": "Processando...",
		"sZeroRecords": "Nenhuma fatura encontrado",
		"sSearch": "Pesquisar",
		"oPaginate": {
        "sNext": "Pr�ximo",
        "sPrevious": "Anterior",
        "sFirst": "Primeiro",
        "sLast": "�ltimo"
        }
		}
		} );
	} );
	</script>
</head>
<body>
<?php
	// ACENTUA��O DA P�GINA
	header('Content-Type: text/html; charset=ISO-8859-1');
	header('Content-Type: text/html; charset=ISO-8859-1');
	require('../funcoes/criarCombo.php'); //Fun��o de convers�o de data para dd/mm/aaaa
	include "../funcoes/conecta_mysql.inc";
	
	$admin = mysql_num_rows(mysql_query("SELECT * FROM hospital.usuarios WHERE Nivel = 3 AND ativo = 1"));
	$visual = mysql_num_rows(mysql_query("SELECT * FROM hospital.usuarios WHERE (Nivel = 2 || Nivel = 8 || nivel = 7) AND ativo = 1"));
	$padrao = mysql_num_rows(mysql_query("SELECT * FROM hospital.usuarios WHERE Nivel = 1 AND ativo = 1"));
	$inativos = mysql_num_rows(mysql_query("SELECT * FROM hospital.usuarios WHERE ativo = 0"));
 
 //INICIA DE ANO E MES 
	$ano_atual = date("Y");
	$dataAtual = date("d-m-Y");
	$dataAtualmod = date("Y-m-d");
	?>
    <table cellspacing="2" cellpadding="0" width="1000" align="center" style="background-color: aliceblue; padding: 1em; border: #69c solid 1px;">
    <tr>
    <td colspan="2">
	<table id="example" class="display" cellspacing="0" cellpadding="0" width="100%" style="color:#666; letter-spacing:0.03px; font-size:11px;">
	<thead>
    <tr> 
      <td colspan="5">
      <span style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:18px; color:#f90;">CADASTRO DE USU�RIOS</span>
      </td>
      <td colspan="4" valign="top">
		<button style="cursor:pointer; background: none; border: none;" title="Incluir um novo usu�rio" onClick="window.AdMmainFrame.location.href='administra_usuarios_incluir.php'">
		<img src="../imagens/incluir.png" width="13" height="13" style="vertical-align:baseline; border:none;">&nbsp;Incluir usu�rio&nbsp;
		</button>
		<button style="cursor:pointer; background: none; border: none;" title="Atualizar" onClick="history.go(0)">
		<img src="../imagens/refresh.png" width="13" height="13" style="vertical-align:baseline; border:none;">&nbsp;Atualizar
		</button>
	  </td>
     <td width="1" rowspan="3" style="border-right: #eee solid 1px;"><img src="../imagens/validar.png" width="15" height="15"></td> 
</tr>
    <tr align="center" style="color:#69C">
      <td width="225" rowspan="2">Nome</td>
      <td width="135" rowspan="2">Login</td>
      <td rowspan="2">Coren</td>
      <td rowspan="2">Categoria</td>
      <td rowspan="2">Referencia</td>
      <td rowspan="2">Vinculo</td>
      <td rowspan="2">setor_ID</td>
	  <td rowspan="2">Nivel</td>
	  <td rowspan="2">ativo</td>	
      <td width="110" colspan="2">�ltimo acesso</td>
    </TR>
    <tr align="center" style="color:#69C">
      <td>Data</td>
      <td>Hora</td>
    </TR>
    </thead>
	<?php
	
    $sql = "SELECT hospital.usuarios.*, hospital.usuarios_nivel.* FROM hospital.usuarios INNER JOIN hospital.usuarios_nivel ON hospital.usuarios_nivel.id_nivel = hospital.usuarios.nivel ORDER BY ID";
    $i = 1;
    $res=mysql_query($sql);
	while($row=mysql_fetch_array($res))
	{
		$id=$row['id'];
		if($row[5]==0){$cor="#999"; $mensagem="Ativar usu�rio";}else{$cor="#444"; $mensagem="Desativar usu�rio";}
		?>
        <tr align="center" style="cursor:pointer; text-transform: uppercase;" title="Editar dados do usu�rio (duplo click) - <?php echo $row[0]; ?>" ondblclick="window.AdMmainFrame.location.href='administra_usuarios_alterar.php?id=<?php echo $row[0];?>'">
        <td style="padding-left: 5px; color:<?php echo $cor; ?>" align="left"><?php echo $row[1]; ?></td>
		<td style="color:<?php echo $cor; ?>"><?php echo $row[2]; ?></td>
		<td style="color:<?php echo $cor; ?>"><?php echo $row[4]; ?></td>
		<td style="color:<?php echo $cor; ?>"><?php echo $row[5]; ?></td>
        <td style="color:<?php echo $cor; ?>"><?php echo $row[6]; ?></td>
        <td style="color:<?php echo $cor; ?>"><?php echo $row[7]; ?></td>
        <td style="color:<?php echo $cor; ?>"><?php echo $row[8]; ?></td>
		<td style="color:<?php echo $cor; ?>"><?php echo $row[9]; ?></td>
		<td style="color:<?php echo $cor; ?>"><?php echo $row[10]; ?></td>
        <td style="color:#93F"><?php if($row[12]>0) echo formataDataHora($row[12],"d-m-Y"); ?></td>
        <td style="color:#f93"><?php if($row[13]>0) echo $row[14]; ?></td>
		<td style="cursor:pointer; opacity:0.6; border-left:#eee solid 1px; border-right: #eee solid 1px;" title="<?php echo $mensagem; ?>">
		<a href='administra_usuario_desativar.php?id=<?php echo $row[0]; ?>' onClick="return confirma_cancel();">
		<?php if ($row[5]==1){
			echo "<img src='../imagens/validar.png' width=11 height=11 align='absmiddle' style='border-radius:15px'>";
			} else {
			echo "<img src='../imagens/esclam.png' width=11 height=11 align='absmiddle' style='border-radius:15px'>";
			} ?> 
		</td>
		</tr>
	<?php
    }

	?>
    </table>
    </td>
    </tr>
    <tr>
      <td valign="top" width="440">
      <iframe src="administra_usuarios_incluir.php" width="100%" height="350" frameborder="0" align="middle" style="border:none;" name="AdMmainFrame"></iframe>
      </td>
      <td width="500" rowspan="2" valign="top"><iframe src="administra_usuarios_logados.php" width="100%" height="310" frameborder="0" align="middle" style="border:none;" name="AdMmainFrame_log"></iframe></td>
      </tr>
    <tr>
    <td width="350" align="left" valign="top">
      <table border="0" cellpadding="2" cellspacing="1" style="background-color:#fff; border: #eee solid 1px;" width="350">
        <tr align="center" style="color:#69c; background-color:aliceblue;">
          <td style="color:#fff; background-color:lightblue">�reas</td>
          <td>Admin</td>
          <td>Visual</td>
          <td>Padr�o</td>
          <td>Inativos</td>
        </tr>
        <tr align="center" style="background-color:aliceblue;">
          <td style="color:#fff; background-color:lightblue">Qte.</td>
          <td><?php echo $admin; ?></td>
          <td><?php echo $visual; ?></td>
          <td><?php echo $padrao; ?></td>
          <td><?php echo $inativos; ?></td>
        </tr>
      </table>
    </td>
   	<td colspan="2" style="background-color: white;" align="right">
    <button type="reset" title="Volar p�gina padr�o"  style="vertical-align:middle" onClick="window.open('administra_janelas.php','mainFrame_bottom')" >Sair</button>
    </td>
    </tr>

    </table>
</body>
</html>
