<?php

// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3;

// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
}
	// ACENTUA��O DA P�GINA
	header('Content-Type: text/html; charset=ISO-8859-1');

	include "../funcoes/conecta_mysql.inc";

	$resultado = mysql_query("DELETE FROM hospital.usuarios WHERE ID=".$_GET['id']);
	if ($resultado) { echo "<script type='text/javascript'>
	alert('Usu�rio exclu�do com sucesso!!!');
	window.location.href='administra_usuarios_listar.php';
	history.go(-1)</script>";
	}	
?>
