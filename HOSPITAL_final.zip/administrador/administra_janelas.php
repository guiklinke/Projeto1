﻿<?php

// A sessão precisa ser iniciada em cada página diferente
$nivel_necessario=0; //Inicializando variável de nível necessário para entrar nesta página
if (!isset($_SESSION)) session_start();

$nivel_necessario = 2;

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] < $nivel_necessario)) {
	// Destrói a sessão por segurança
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
}
?>
<html>
<head>
<title>ADMINISTRAÇÃO</title>
</head>
<FRAMESET ROWS="31,*" border="0">
<FRAME src="administra_menu.php" NORESIZE SCROLLING="NO" name="topFrameDoc">
<FRAME src="" NORESIZE SCROLLING="YES" name="mainFrameDoc" style="background: none;">
</frameset>
<noframes>
<body>
</body>
</noframes>
</FRAMESET>
</html>
