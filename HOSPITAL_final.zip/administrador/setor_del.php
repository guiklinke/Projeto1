<?php
session_start();
  include "../funcoes/conecta_mysql.inc";
$q = "SELECT setor_ID, Nome_setor FROM setores";
$setores= mysql_query( $q, $conexao1); 
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <title> Deletar Setores </title>
    <link rel="stylesheet" type="text/css" href="estilo1.css"/>
  <head>
  
  <style>
  
  body {
  background-image: url('logo.png');
  background-repeat: no-repeat;
  background-size: 15% 25%; 
  background-position: top right;
  background-attachment: fixed;
  }
  
  
  </style>
   
  
  <body>
    
    <div class="div1d">
     
     <div class="divtitulod"><span style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:15px; color:#f90;width:130px;position: absolute; margin-left: 60px;margin-top: 10px">Deletar Setores</span></div> <!-- fim div titulo-->
   
   
    
    
    <div class="div2d">
    <form method="POST" action="deleta_setor.php">
     
      <select name="setor" id="setor" style="position: absolute; margin-left: 10px; margin-top: 50px">
                                        <option>Selecione o setor a ser deletado:</option>
            <?php
            while ($m = mysql_fetch_assoc($setores)) {
              
            ?>

                <option value="<?php echo $m['setor_ID']; //aqui vai o valor a ser guardado no POST?>"><?php echo $m['Nome_setor']; //aqui vai o que vai ser mostrado?></option> 
            <?php
            }
        ?>
        </select>
      </div> <!-- fim div 2-->
       <div class="divbotaod"><input type="submit" value="DELETAR" style="position: absolute; margin-left: 50px;margin-top: -8px"> </div> <!-- fim div botao-->
      
      <?php
        if (isset ($_SESSION['msg'])) { 
        echo $_SESSION['msg'];
        unset ($_SESSION['msg']);
        } 
      ?>
      
      </form>
      </div> <!-- fim div 1-->
  </body>
</html>