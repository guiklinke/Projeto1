<?php
// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=8; charset=iso-8859-1"/>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" type="text/css" href="../funcoes/css/style_contspi.css">
	<link rel="stylesheet" type="text/css" href="../funcoes/css/style_thin.jquery.dataTables.min.css">
	<script type="text/javascript" language="javascript" src="../funcoes/js/jquery-1.12.3.min.js"></script>
	<script type="text/javascript" language="javascript" src="../funcoes/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="../funcoes/js/ajax.js"></script>
    <script type="text/javascript" language="javascript" src="administra_usuarios.js"></script>
	<script type="text/javascript" language="javascript" class="init">
		$(document).ready(function() {
			$('#example').DataTable( {
			} );
		} );
	</script>
	<style>
	
	body {
	font-family: Trebuchet MS, Arial, Helvetica, sans-serif;
	font-size: 11px;
	/*line-height: 11px;*/
	background: none;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 5px;
	margin-bottom: 5px;
	}
	/*input[type="text"]{
		border-radius:2px;
		border-style:none;
		border-width:thin;
		border-color:#ddd;
		vertical-align:middle;
		text-align:center;
		height:12px;
	}*/
	table.dataTable.hover tbody tr:hover,table.dataTable.display tbody tr:hover{
	background-color:#FFF;
	}
    </style>
	<script language="Javascript">
               function confirma_senha()
                        {
                                var resp = confirm("Confirma retorno da senha para padr�o");
                                if (resp){
                                return true;
                                }
                                else{
                                return false;
                                        }
                }
    </script>        
</head>
<body>
     <?php
	# Acentua��o da p�gina
	header('Content-Type: text/html; charset=ISO-8859-1');
	# Fun��o de convers�o de data para dd/mm/aaaa
 	require('../funcoes/criarCombo.php');
	# Faz a conex�o com o banco de dados
	include "../funcoes/conecta_mysql.inc";

	$id=$_GET["id"]; # Usa o ID para atualizar os dados
    $i = 1; # Inicia a vari�vel para o campo a ser editado

	# Seleciona o registro a ser atualizado
    $reg_usu = mysql_fetch_row(mysql_query("SELECT * FROM hospital.usuarios where ID=".$_GET["id"]));

	?>
<table width="430" border="0" cellpadding="0" cellspacing="2">
  <tbody>
    <tr>
      <td>
<form method="GET" name="alterar_usuario" action="administra_usuarios_alterar_db.php">
 <table width="430" cellpadding="0" cellspacing="0" style="color:#69C; border-top: #eee solid 1px; border-right: #eee solid 1px; table.dataTable.hover tbody tr:hover,table.dataTable.display tbody tr:hover{ background-color:#FFF; }" id="example" class="display">
  <tr>
    <td width="50">&nbsp;Nome</td>
    <td colspan="6" style="color: #000; font-size: 11px; text-transform: uppercase; padding: 5px;">
    <?php if($reg_usu[1]!=''){$nome=$reg_usu[1];}else{$nome="...";};
	echo "<span id=\"campo$i\"><span onclick=\"editar($i,this,".$id.",'Nome');\" title=\"$id campo$i\">".$nome."</span></span>"; ?>	
	</td><?php echo "\n"; $i++; ?>
  </tr>
  <tr>
    <td>&nbsp;Login</td>
    <td colspan="6" style="color: #000; font-size: 11px; text-transform: uppercase; padding: 5px;">
    <?php if($reg_usu[2]!=''){$login=$reg_usu[2];}else{$login="...";};
	echo "<span id=\"campo$i\"><span onclick=\"editar($i,this,".$id.",'Login');\" title=\"$id campo$i\">".$login."</span></span>"; ?>	
	</td><?php echo "\n"; $i++; ?>
  </tr>
  <tr>
    <td>&nbsp;Coren</td>
    <td colspan="6" style="color: #000; font-size: 11px; text-transform: uppercase; padding: 5px;">
    <?php if($reg_usu[4]!=''){$coren=$reg_usu[4];}else{$coren="...";};
	echo "<span id=\"campo$i\"><span onclick=\"editar($i,this,".$id.",'Coren');\" title=\"$id campo$i\">".$coren."</span></span>"; ?>	
	</td><?php echo "\n"; $i++; ?>
  </tr>
  <tr>
    <td>&nbsp;Categoria</td>
    <td colspan="6" style="color: #000; font-size: 11px; text-transform: uppercase; padding: 5px;">
    <?php if($reg_usu[5]!=''){$categoria=$reg_usu[5];}else{$categoria="...";};
	echo "<span id=\"campo$i\"><span onclick=\"editar($i,this,".$id.",'Categoria');\" title=\"$id campo$i\">".$categoria."</span></span>"; ?>	
	</td><?php echo "\n"; $i++; ?>
  </tr>
  <tr>
	 <td>&nbsp;Referencia</td>
    <td colspan="6" style="color: #000; font-size: 11px; text-transform: uppercase; padding: 5px;">
    <?php if($reg_usu[6]!=''){$referencia=$reg_usu[6];}else{$referencia="...";};
	echo "<span id=\"campo$i\"><span onclick=\"editar($i,this,".$id.",'Referencia');\" title=\"$id campo$i\">".$referencia."</span></span>"; ?>	
	</td><?php echo "\n"; $i++; ?>
  </tr>
  <tr>
    <td>&nbsp;N�vel</td>
    <td colspan="6">
    <select name="Nivel" class="doc_select" style="color: #000; font-size: 11px; text-transform: uppercase;" onChange="this.form.submit()">
	<?php criarComboEditar("hospital.usuarios_nivel",0,1,$reg_usu[9],"Desc_nivel");?>
	</select>
	</td>
  </tr>
  <tr align="right" height="30px">
    <td colspan="6" align="center">
      <a href='administra_voltar_senha.php?id=<?php echo $_GET["id"];; ?>' onClick="return confirma_senha();"><img src="../imagens/cadeado.png" width="17" height="13" style="vertical-align:baseline; border:none;">&nbsp;Voltar para senha padr�o&nbsp;&nbsp;</a>
      </td>
    <td>
      <input type="hidden" name="enviar" value="S">
      <input type="hidden" name="id" value="<?php echo $_GET["id"]; ?>">
      <input type=button value="Voltar" onClick="javascript:history.back(1)" style="vertical-align:middle">
      </td>
  </tr>
</table>
</form>
    



