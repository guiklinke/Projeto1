<?php
include "../funcoes/conecta_mysql.inc";
$q = strtolower($_GET["q"]);
if (!$q) return;

$sql = "select DISTINCT Nome,Login,ID from hospital.usuarios where nome LIKE '%$q%'";
$rsd = mysql_query($sql);
while($rs = mysql_fetch_array($rsd)) {
	$cname = utf8_encode($rs['Nome']);
	$cname2 = utf8_encode($rs['Login']);
	echo "$cname ($cname2)\n";
}
?>