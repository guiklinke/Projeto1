<?php
session_start();
include "../funcoes/conecta_mysql.inc";


$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);



$result_hosp = "INSERT INTO setores (Nome_setor,Setor_ativo) VALUES ('$nome','1')";
$resultado_hosp = mysql_query( $result_hosp, $conexao1);

if (mysql_insert_id($conexao1)) {
	
	$_SESSION['msg'] = "<p style= color:blue;'>CADASTRADO COM SUCESSO!! </p>";
	header ("Location: setores.php");
} else {
	$_SESSION['msg'] = "<p style= color:red;'>NÃO CADASTRADO!!</p>";
	header ("Location: setores.php");
	
}


