<?php

// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
}
	// ACENTUA��O DA P�GINA
	header('Content-Type: text/html; charset=ISO-8859-1');

	require('../funcoes/convertdata.php'); //Fun��o de convers�o de data para dd/mm/aaaa
	include "../funcoes/conecta_mysql.inc"; // Faz a conex�o com o banco de dados
	
	$dataAtual = date("Y-m-d"); //Seleciona a data atual para inserir no banco de dados 

	$res = mysql_query("INSERT INTO hospital.usuarios (Nome, Login, Coren, Categoria, Referencia, Vinculo, Nome_setor, Senha ) VALUES ('".$_GET["Nome"]."','".$_GET["Login"]."','".$_GET["Coren"]."','".$_GET["Categoria"]."','".$_GET["Referencia"]."','".$_GET["Vinculo"]."','".$_GET["Nome_setor"]."', '1234')");
	if ($res){
	echo "<script type='text/javascript'>
	alert('Usu�rio cadastrado com sucesso!!!');
	</script>";
	header("Location: administra_usuarios_alterar.php?ID=". mysql_insert_id());
	}
	?>
