<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8"/>
	<title>Setores</title>
  <link rel="stylesheet" type="text/css" href="estilo1.css"/>
	
</head>
<style>
  
  body {
  background-image: url('logo.png');
  background-repeat: no-repeat;
  background-size: 15% 25%; 
  background-position: top right;
  background-attachment: fixed;
  }
  
  
  </style>
<body>

<div class="div1">
		
	<div class="divtitulo"><span style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:15px; color:#f90;width:130px;position: absolute; margin-left: 34px;margin-top: 10px">Cadastrar Setores</span></div> <!-- fim div titulo-->
  


  <div class="div2">
<form method="POST" action="cadastra_setor.php">
	<input type="text" name="nome" placeholder="Nome" style="position: absolute; margin-left: 8px; margin-top: 50px">
 
</div> <!-- fim div 2-->

 <div class="divbotao"> <input type="submit" value="CADASTRAR" style="position: absolute; margin-left: 50px"> </div> <!-- fim div botao-->
	
      
</form>
 </div> <!-- fim div 1-->
<?php
        if (isset ($_SESSION['msg'])) { 
        echo $_SESSION['msg'];
        unset ($_SESSION['msg']);
        } 
     ?>
</body>
</html>