<?php

// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
}
	// ACENTUA��O DA P�GINA
	header('Content-Type: text/html; charset=ISO-8859-1');

	include "../funcoes/conecta_mysql.inc";
	$buscaAtivo=mysql_fetch_row(mysql_query("SELECT * FROM hospital.usuarios WHERE ID='".$_GET['id']."'"));
	if($buscaAtivo[5]==1){
	$resultado = mysql_query("UPDATE hospital.usuarios SET ativo=0 WHERE ID='".$_GET['id']."'");
	$mensagem="Desativado";
	}else{
	$resultado = mysql_query("UPDATE hospital.usuarios SET ativo=1 WHERE ID='".$_GET['id']."'");
	$mensagem="Ativado";
	}
	if ($resultado) { echo "<script type='text/javascript'>
	alert('Usu�rio $mensagem com sucesso!!!');
	history.go(-1)</script>";
	}
?>
