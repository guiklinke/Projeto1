<?php
// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="funcoes/css/style_menu.css" />
<style type="text/css">
body {
	background-color:#333333;
	}
</style>
</head>
<body>

<?php
	header('Content-Type: text/html; charset=ISO-8859-1');
	
	include "funcoes/conecta_mysql.inc";
	$sql_pr= mysql_fetch_row(mysql_query("select * From hospital.usuarios where ID =".$_GET["UsuarioID"])); #Seleciona os Usuarios
	define("usuario_atual",$sql_pr[1]);
?>

<table cellpadding="0" cellspacing="0" width="100%" border="0">
<tr>
<td width="160"  onClick="history.go(0)" style="cursor: pointer; border: none;"><img src="imagens/logo.png" width="80" height="60" alt="" border=0/></td>
<td width="250" align="center">
<button style="background: none; border: none; color:darkgray; font-size: 16px; background-color: black; padding: 1px 6px 3px 6px; border-radius: 3px;">Sistema de Controle de Escala&nbsp;<span style="color: white; font-size: 16px;"><?php echo $_SESSION['setor'] ;?></span></button>
</td>
<td>
  

<table cellpadding="0" cellspacing="0" align="left" style="padding-bottom:2px;">
<tr>

<td>    
 	<form action="sistema/escala/escala_criacao.php" target="mainFrame_bottom" method="get">
		<button class="btn_cinza_escuro" title="Altera��o de dados/ Inclus�o de Instrumento">Cadastro de <br> Escala</button>
    </form>
</td>


<td>    
 	<form action="sistema/escala/escala_presenca.php" target="mainFrame_bottom" method="get">
		<button class="btn_cinza_escuro" title="Altera��o de dados/ Inclus�o de Instrumento">Lista de <br> Presen�a</button>
    </form>
</td>


<td> 
	<form action="old_files/listar_escalas.php" target="mainFrame_bottom" method="get">
		<button class="btn_laranja" title="Lista do Corpo Cl�nico - Listar, imprimir para PDF e exportar para EXCEL.">Lista de <br>Escala</button>
		<input type="hidden" name="nomeLista" value=1>
    </form>
</td>
<td> 
	<form action="sistema/listas/listas_janelas.php" target="mainFrame_bottom" method="get">
		<button class="btn_laranja" title="Lista do Corpo Cl�nico - Listar, imprimir para PDF e exportar para EXCEL.">Lista do <br>Corpo Cl�nico</button>
		<input type="hidden" name="nomeLista" value=1>
    </form>
</td>

</tr>    
</table>
</td>
<td width="200" valign="middle" align="right">
<table cellpadding="0" cellspacing="1" style="padding-bottom: 2px;" align="right">
<tr>

<td align="right"><?php if($_SESSION['UsuarioNivel']==3){ ?>
<button class="btn_cinza_escuro" style="cursor:pointer; width: 80px;" onClick="window.open('administrador/administra_janelas.php','mainFrame_bottom')"title="Menu do Administrador">
<img src="imagens/administrador.png" width="17" height="17" style="vertical-align:middle; border:none; color:darkgray;">&nbsp;&nbsp;<span style="vertical-align:middle; font-size: 11px;">Admin</span></button> <?php } ?>
</td>

<td align="right">
<button class="btn_cinza_escuro" style="cursor:pointer; width: 80px;" onClick="window.open('alterar_senha.php','mainFrame_bottom')"title="Alterar senha">
<img src="imagens/cadeado.png" width="24" height="17" style="vertical-align:middle; border:none; color:darkgray;">&nbsp;&nbsp;<span style="vertical-align:middle; font-size: 11px;">Senha</span></button>
</td> 


<td align="right" style="width: 122px;">
<button class="btn_cinza_escuro" style="cursor: pointer; width: 120px;" onClick="window.open('logout.php','mainFrame_top')" title="Sair"><img src="imagens/images.png" width="17" height="17" style="vertical-align:middle; border:none; color:darkgray;">&nbsp;&nbsp;<span style="vertical-align:middle; font-size: 11px;"><?php echo $_SESSION['Usuario'] ;?>&nbsp;&nbsp;</span>
</button>
</td>
</tr>
</table>
</tr>
</table>
</body>
</html>
