﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" HREF="logo.png">
<title>Sistema de Controle de Escala</title>
</head>
<frameset rows="60,*" border="0">
<frame src="login.php" name="mainFrame_top" scrolling="NO" noresize>

<frame src="" name="mainFrame_bottom" style="border-top: #f93 solid 1px; background-image: url(imagens/fundo.png); background-repeat: no-repeat;background-size: 100% 100%;">
</frameset><noframes></noframes> 
</HTML>