<?php
	session_start(); // Inicia a sess�o
	session_destroy(); // Destr�i a sess�o limpando todos os valores salvos
	session_unset(); //limpamos as variaveis globais das sess�es
	// aqui voc� pode por alguma coisa falando que ele saiu ou fazer como eu, coloquei redirecionar para uma certa p�gina
	echo "<script>alert('Logoff efetuado!');top.location.href='index.php';</script>";
?>