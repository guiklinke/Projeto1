<?php

// A sessão precisa ser iniciada em cada página diferente
$nivel_necessario=0; //Inicializando variável de nível necessário para entrar nesta página
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destrói a sessão por segurança
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
}
	// ACENTUAÇÃO DA PÁGINA
	header('Content-Type: text/html; charset=ISO-8859-1');

	require('../../funcoes/convertdata.php'); //Função de conversão de data para dd/mm/aaaa
	include "../../funcoes/conecta_mysql.inc"; // Faz a conexão com o banco de dados

	$ID = $_GET['Usu_ID'];


	$cont = 0 ;	

	foreach ($ID as $key => $value) {
		$p = "UPDATE hospital.usuarios_dias_escalas  SET hospital.usuarios_dias_escalas.Presenca = 'P' WHERE hospital.usuarios_dias_escalas.user_esc_day_ID=$value";
	    if ($res =  mysql_query($p)){

	    }else{
	    	$cont = $cont + 1;
	    }
	   
	}


if ($cont < 1) {
	
	$_SESSION['msg'] = "<p style= color:blue;'>PRESENÇA ALTERADA COM SUCESSO!! </p>";
	header ("Location: escala_presenca.php");
} else {
	$_SESSION['msg'] = "<p style= color:red;'>PRESENÇA NÃO ALTERADA!!</p>";
	header ("Location: escala_presenca.php");
	
}
	













?>