<?php
// A sessão precisa ser iniciada em cada página diferente
$nivel_necessario=0; //Inicializando variável de nível necessário para entrar nesta página
if (!isset($_SESSION)) session_start();
include "../../funcoes/conecta_mysql.inc";
$nivel_necessario == 3+1;

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
  // Destrói a sessão por segurança
  session_destroy();
  // Redireciona o visitante de volta pro login
  header("Location: index.php"); exit;
} 
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <title> HOSPITAL - Cadastro </title>
     <link rel="stylesheet" type="text/css" href="estilo1.css"/>
  <head>
  
  <style>
  
  body {
  background-image: url('logo.png');
  background-repeat: no-repeat;
  background-size: 15% 25%; 
  background-position: top right;
  background-attachment: fixed;
  }
  
  
  </style>
   
  
  <body>

    <div class="div1d">
    


    <div class="divtitulod"><span style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:15px; color:#f90;width:130px;position: absolute; margin-left: 70px;margin-top: 10px">Criar Escala</span></div> <!-- fim div-->
    

    <div class="div2d">
    
    
    <form method="POST" action="criar_escala.php">
      <label style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:15px; color:#f90;">Data de Início: </label>
      <input type="date" id="inicio" name="inicio"><br><br>
      <label style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:15px; color:#f90;">Data de Fim: </label>
      <input type="date" id="fim" name="fim"><br><br>
      
      <label style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:15px; color:#f90;">Turno: </label>
      <select name="turno" id="turno">
                                        <option>Escolha o Turno:</option>
            <option value="Manha">Manhã</option>
            <option value="Integral">Integral</option>
            <option value="Noturno">Noturno</option>
      </select>

      </div> <!-- fim div 2-->

      
      <div class="divbotaod"><input type="submit" value="CRIAR"style="position: absolute; margin-left: 60px;margin-top: -8px"> </div> <!-- fim div botao-->
      
      
      
      </form>

      </div> <!-- fim div 1-->
      <?php
        if (isset ($_SESSION['msg'])) { 
        echo $_SESSION['msg'];
        unset ($_SESSION['msg']);
        } 
      ?>
  </body>
</html>