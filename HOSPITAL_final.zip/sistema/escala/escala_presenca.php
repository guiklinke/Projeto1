<?php

			

// A sessão precisa ser iniciada em cada página diferente
$nivel_necessario=0; //Inicializando variável de nível necessário para entrar nesta página
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destrói a sessão por segurança
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Testes modal</title>
	<link rel="stylesheet" type="text/css" href="../funcoes/css/estilo.css"/>

</head>
<body>




		<div class="divpresenca">

			
			
			<div class="filtro"> 

				<form method="get" action="">

					<select name="escala" id="escala" class="escala">
                                        <option value = NULL>Escala</option>
            			<?php
            			 include "../../funcoes/conecta_mysql.inc";
            			 $q = "SELECT hospital.escalas.esc_ID, hospital.escalas.inicio, hospital.escalas.fim, hospital.escalas.turno FROM hospital.escalas";
 						 $escalas= mysql_query($q); 
           				 while ($getescalasline =  mysql_fetch_array($escalas)) {
								$inicio = $getescalasline['inicio'];
								$fim = $getescalasline['fim'];
								$turno = $getescalasline['turno'];
								$escalaid = $getescalasline['esc_ID'];

								

								echo "<option value='$escalaid'> Inicio: $inicio, Fim: $fim,Turno: $turno </option>";
							}
        				?>
        			</select>

					
					<select name="setor" class="select">
						<option value=""> Setor </option>
						<?php
							include "../../funcoes/conecta_mysql.inc";
							$getsetor = "SELECT hospital.setores.Setor_ID, hospital.setores.Nome_setor FROM hospital.setores";
							$getsetorsql = mysql_query($getsetor);
							while ($getsetorline =  mysql_fetch_array($getsetorsql)) {
								$setor = $getsetorline['Nome_setor'];
								$setorid = $getsetorline['Setor_ID'];
								echo "<option value='$setorid'> $setor </option>";
							}
						?>
					</select>


					
					<input class = "data" type="date" name="data" style="height: 20px;" />
					<input class ="filtrar" type="submit" name="submit" value="FILTRAR" style="width:  75px;" />

				</form>

			</div>


			




			<form method="get" action="criar_presenca.php">

				<?php 
					$rescala = $_GET['escala'];
					$rsetor = $_GET['setor'];
					$rdata = $_GET['data'];
					
					$escala_data_q = "SELECT  hospital.escalas.inicio, hospital.escalas.fim, hospital.escalas.turno FROM hospital.escalas WHERE hospital.escalas.esc_ID = $rescala";
					$escala = mysql_query($escala_data_q);
					$getescalasline = mysql_fetch_array($escala);
					$inicio = $getescalasline['inicio'];
					$fim = $getescalasline['fim'];
					$turno = $getescalasline['turno'];

					$rnome = "SELECT hospital.setores.Nome_setor FROM hospital.setores WHERE hospital.setores.Setor_ID = $rsetor";
					$nome = mysql_query($rnome);
					$linha = mysql_fetch_array($nome);



					?>

				<div class="confirmacao"> 


				<table class="titulo" style="width:840px" >
				<tr > 
					<td style="width: 80px;"><span style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:15px; color:#f90;width:130px;">PRESENÇA</span> </td>
					<td style="width: 230px;"><span style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:10px; color:#f90;width:290px;"><?php echo "$inicio A $fim $turno";?></span></td>
					<td style="width: 430px;"><span style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:10px; color:#f90;width:290px;">Setor: <?php echo $linha['Nome_setor']?></span></td>
					<td style="width: 100px;"><span style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:10px; color:#f90;width: 150px;">Dia: <?php echo $rdata ?></span></td>
						
				</tr>
				</table>

			</div>



			<table class="tabelalista" >	
				<thead class="theadlista">
					


					
				
					<tr>
						<td  style="width: 780px; border-bottom: 1px solid #eee;color: rgb(102,153,204);">NOME </td>
						<td style="width: 100px;text-align:center;vertical-align:middle; border-bottom: 1px solid #eee;color: rgb(102,153,204);" >RE/RF</td>
					</tr>


				</thead>
				
				<tbody class="tbodylista" >

						<?php
								
						$result_hosp = "SELECT hospital.usuarios_dias_escalas.user_ID,hospital.usuarios_dias_escalas.Presenca, hospital.usuarios_dias_escalas.user_esc_day_ID,hospital.usuarios.Nome 
							FROM 
							  hospital.usuarios_dias_escalas 
							  INNER JOIN 
							  hospital.usuarios 
							  ON hospital.usuarios.ID = hospital.usuarios_dias_escalas.user_ID 

							AND  hospital.usuarios_dias_escalas.dia = '$rdata' 
							AND  hospital.usuarios_dias_escalas.esc_ID IN (
							SELECT hospital.usuarios_escalas.esc_ID FROM hospital.usuarios_escalas WHERE
							 hospital.usuarios_escalas.esc_ID = $rescala
							)";
						$resultado_hosp = mysql_query($result_hosp);
						while ($row_hosp = mysql_fetch_array($resultado_hosp)){

						
						?>
						

				<tr class="trbody">  
							<td style="width: 780px; border-bottom: 1px solid #eee;border-right: 1px solid #eee;">


								
								<input type="checkbox" name="Usu_ID[]" value= " <?php echo $row_hosp['user_esc_day_ID'];?>" <?php if ($row_hosp['Presenca']=='P') echo "checked"?> > <?php echo $row_hosp['Nome']?>
								




							</td>
							
							<td style="width: 100px;text-align:center;vertical-align:middle;border-bottom: 1px solid #eee;border-right: 1px solid #eee;"><?php echo $row_hosp['user_ID'] ;?> </td>

					</tr> 

						<?php } ?>

				</tbody>	
			</table>
			<input type="submit" class="botao" value="Enviar">
			</form>




		</div>

		
		<?php
        if (isset ($_SESSION['msg'])) { 
        echo $_SESSION['msg'];
        unset ($_SESSION['msg']);
        } 
      ?>

	
</body>
</html>