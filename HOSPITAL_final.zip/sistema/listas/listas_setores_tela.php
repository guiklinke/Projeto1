<?php
// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" type="text/css" href="../../funcoes/css/style_menu.css">
	<link rel="stylesheet" type="text/css" href="../../funcoes/css/style_contspi.css">
	<link rel="stylesheet" type="text/css" href="../../funcoes/css/style_thin.jquery.dataTables.min.listas.css">
	<link rel="stylesheet" type="text/css" href="../../funcoes/css/style_fixedColumns.dataTables.css">
	<style type="text/css" class="init">
	
	/* Ensure that the demo table scrolls */
	th, td { white-space: nowrap; }
	div.dataTables_wrapper {
	width: 100%;
	margin: 0 auto;
	}
	td.highlight {
	background-color: #EEEEEE !important;
	}
    body {
	/*margin-left: 10px;
	margin-right: 10px;
	margin-bottom: 10px;*/
	margin: 0px;
	background: none;
	background-color:aliceblue;
	color: #444;
	font-size: 11px;
	}
    </style>
    <script type="text/javascript" language="javascript" src="../../funcoes/js/jquery.js"></script>
	<script type="text/javascript" language="javascript" src="../../funcoes/js/jquery.dataTables.js"></script>
	<script type="text/javascript" language="javascript" src="../../funcoes/js/jquery.dataTables.fixedColumns.js"></script>
	<script type="text/javascript" language="javascript" src="../../funcoes/js/jquery.dataTables.fixedColumns.min.js"></script>
	<script type="text/javascript" language="javascript" src="../../funcoes/js/ajax.js"></script>
    <script type="text/javascript" language="javascript" src="js/listas_alterar.js"></script>
	<script type="text/javascript" language="javascript" class="init">

$(document).ready(function() {
    $('#example').DataTable( {
		"dom":'<"top"i>rt<"bottom"flp><clear>',
        scrollY:        "85vh",
        scrollX:        true,
        scrollCollapse: true,
        "paging":         false,
		"ordering":       false,
		"info":			  false,
        fixedColumns:   {
            leftColumns: 3,
			rightColumns: 1,
        }
    } );
} );
	</script>
</head>
<body>
<?php
	// ACENTUA��O DA P�GINA
	header('Content-Type: text/html; charset=ISO-8859-1');
	date_default_timezone_set('America/Sao_Paulo');
	require('../../funcoes/criarCombo.php');
	include "../../funcoes/conecta_mysql.inc";
	
	
 
	
	$lista = $_GET["lista"];
		if($lista==1) {$campo = "li"; $nomeForm = "Lista dos Setores";}
	elseif($lista==2) {$campo = "lo"; $nomeForm = "Lista de entradas/sa�das";}
	elseif($lista==3) {$campo = "ls"; $nomeForm = "Lista de Set-Points";}
	elseif($lista==4) {$campo = "fi"; $nomeForm = "Folha de Dados de Instrumentos";}

	
		
    $sql = mysql_query("SELECT * FROM setores ORDER BY Nome_setor");
					
	?>
	
<table id="example" class="stripe row-border order-column, display" cellspacing="0" cellpadding="0" width="100%" style="text-transform: uppercase;">
   <thead>
    <tr align="center" style="color: #666">
      
      <th rowspan="5" width="38" style="border-bottom: 1px solid #ccc;">Setor_ID</th>
      <th rowspan="5"width="36" style="border-bottom: 1px solid #ccc;">Nome</th>
      <th rowspan="5"width="25"  style="border-bottom: 1px solid #ccc;">Numero Minimo</th>  
      <th rowspan="5" width="43" style="border-bottom:1px solid #ccc">Ativo</th>      
     </tr>
   </thead>
   <tbody>
    <?php
	$i = 1;
	while($row=mysql_fetch_array($sql))
	{
		$row_tipico=mysql_fetch_array($sql_tipico);
		echo $row_tipico[69];
	$id = $row[0];
	?>   
    	<tr align="center" style="text-transform: uppercase; cursor: pointer;" <?php echo $row[0]; ?>', 'mainFrame_bottom')">
			<td><?php altera_dado($row["Setor_ID"], "ID" ,$i,$id,3,2,1) ?></td><?php echo "\n"; $i++; ?>
			<td><?php altera_dado($row["Nome_setor"], "Nome",$i,$id,3,2,1) ?></td><?php echo "\n"; $i++; ?>
			<td><?php altera_dado($row["Numero_minimo_de_pessoas"], "min" ,$i,$id,3,2,1) ?></td><?php echo "\n"; $i++; ?>
			<td><?php altera_dado($row["Setor_ativo"], "Ativo",$i,$id,3,2,1) ?></td><?php echo "\n"; $i++; ?>
        </tr>
        <?php } ?>
   </tbody>
</table>
</body>
</html>
