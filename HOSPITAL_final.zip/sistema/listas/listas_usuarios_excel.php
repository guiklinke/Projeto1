<?php
// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 

// ACENTUA��O DA P�GINA
	header('Content-Type: text/html; charset=ISO-8859-1');
	date_default_timezone_set('America/Sao_Paulo');
	require('../../funcoes/criarCombo.php');
	include "../../funcoes/conecta_mysql.inc";
	
	$projeto = $_SESSION['projeto'];
 
	$predio = $_GET["predio"];
	$sistema = $_GET["sistema"];
	
	$lista = $_GET["lista"];
		if($lista==1) {$campo = "li"; $nomeForm = "Lista de Instrumentos";}
	elseif($lista==2) {$campo = "lo"; $nomeForm = "Lista de Vari�veis de I/O";}
	elseif($lista==3) {$campo = "ls"; $nomeForm = "Lista de Set-Points";}
	elseif($lista==4) {$campo = "fi"; $nomeForm = "Folha de Dados de Instrumentos";}

	
    $sql = mysql_query("SELECT hospital.usuarios.*, hospital.usuarios_nivel.* FROM hospital.usuarios INNER JOIN hospital.usuarios_nivel ON hospital.usuarios_nivel.id_nivel = hospital.usuarios.nivel ORDER BY Nome");
	
	$html .='<table border=1 cellspacing=0 cellpadding=0 width="100%">';
	$html .='<thead>';	
	$html .='<tr align="center">';
    $html .='<th rowspan="1">Nome</th>';
    $html .='<th rowspan="1">V�nculo</th>';
	$html .='<th rowspan="1">RF/RE</th>';
    $html .='<th rowspan="1">Categoria</th>';
    $html .='<th rowspan="1">COREN</th>';
    $html .='<th rowspan="1">Nome do Setor</th>';
	
	
	$html .='</thead>';
     
	$i = 1;
	while($row=mysql_fetch_array($sql))
	{
	$id = $row[0];
	   
    	$html .= '<tr align="center" style="text-transform: uppercase">';
			$html .= '<td>'.$row["Nome"].'</td>';
			$html .= '<td>'.$row["Vinculo"].'</td>';
			$html .= '<td>'.$row["Referencia"].'</td>';
			$html .= '<td>'.$row["Categoria"].'</td>';
			$html .= '<td>'.$row["Coren"].'</td>';
			$html .= '<td>'.$row["Nome_setor"].'</td>';			
	
			
        }
	    $html .= '</table>';

		//CRIA O ARQUIVO EXCEL
		$arquivo = 'Lista do Corpo Clinico.xls';
		header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
		header ("Last-Modified: " . gmdate("D,d M YH:i:s") . " GMT");
		header ("Cache-Control: no-cache, must-revalidate");
		header ("Pragma: no-cache");
		header ("Content-type: application/x-msexcel");
		header ("Content-Disposition: attachment; filename={$arquivo}" );
		header ("Content-Description: PHP Generated Data" );

		echo $html;
		exit;
?>
   
