<?php

extract($_POST);

// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" type="text/css" href="../../funcoes/css/style_menu.css">
	<link rel="stylesheet" type="text/css" href="../../funcoes/css/style_contspi.css">
	<style type="text/css" class="init">
    body {
	margin 0px;
	background: none;
	}
    body,td,th {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	}
    </style>
</head>


	<script type="text/javascript" language="javascript" src="../../../funcoes/js/ajax.js"></script>
    <script type="text/javascript" language="javascript" src="../materiais/js/materiais_alterar.js"></script>

	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<script>

	function getSistema(val)
	{
		$.ajax({
			type: "POST",
			url: "listas_pesquisa_sistema.php",
			data: 'predioid='+val,
			success: function(data){
				$("#sistema-lista").html(data);
			}
		});
	}

	function getDocumentoLM(val)
	{
		$.ajax({
			type: "POST",
			url: "listas_pesquisa_documento_lm.php",
			data: 'predioid='+val,
			success: function(data){
				$("#documento-lista-lm").html(data);
			}
		});
	}

	function getDocumento(val,lista)
	{

		var  e = document.getElementById ("predio-lista");
		var  predio = e.options[e.selectedIndex].text;

		$.ajax({
			type: "POST",
			url: "listas_pesquisa_documento.php",
			data: 'sistemaid='+val+'&listaid='+lista+'&predioid='+predio,
			success: function(data){
				$("#documento-lista").html(data);
			}
		});
	}
	</script>


<body>
	<?php
	
		# ACENTUA��O DA P�GINA
		header('Content-Type: text/html; charset=ISO-8859-1');
		date_default_timezone_set('America/Sao_Paulo');
		include "../../funcoes/conecta_mysql.inc";
	
		$projeto = $_SESSION['projeto'];

		$lista = $_GET["nomeLista"];
			if($lista==1) {$nomeForm = "Lista do Corpo Cl�nico";
						   $script_form1 = "listas_usuarios_tela.php";
						   $script_form2 = "listas_usuarios_pdf.php";
						   $script_form3 = "listas_usuarios_excel.php";}
		elseif($lista==2) {$nomeForm = "Escala";
						   $script_form1 = "listas_escala_tela.php";
						   $script_form2 = "listas_escala_pdf.php";
						   $script_form3 = "listas_usuarios_excel.php";}
		elseif($lista==3) {$nomeForm = "Lista de Set-Points";
						   $script_form1 = $projeto."_listas_instrumentos_ls.php";
						   $script_form2 = $projeto."_listas_ls.php";
						   $script_form3 = $projeto."_listas_instrumentos_ls_excel.php";}
		elseif($lista==4) {$nomeForm = "Folha de Dados de Instrumentos";
						   $script_form1 = $projeto."_listas_instrumentos_fi.php";
						   $script_form2 = $projeto."_listas_fi.php";
						   $script_form3 = $projeto."_listas_instrumentos_fi_excel.php";}
		elseif($lista==5) {$nomeForm = "Lista de Materiais";
						   $script_form1 = $projeto."_listas_materiais.php";
						   $script_form2 = $projeto."_listas_lm.php";
						   $script_form3 = $projeto."_listas_instrumentos_lm_excel.php";
						   $script_form4 = "../materiais/materiais_alterar_tab_aux_tipo.php";
						   $script_form5 = "../materiais/materiais_tab_aux_tipo.php";
						   $script_form6 = "../materiais/materiais_tab_tipicos.php";
						   $script_form7 = "../materiais/materiais_planta_tab_aux_tipo.php";
						  }

	//echo "$lista";
	//break
	?>

		<script LANGUAGE="JavaScript">
		function opcao1()
			{
			document.form_lista.action="<?php echo $script_form1; ?>";
			document.forms.form_lista.submit();
			}
		</script>
		
		<script LANGUAGE="JavaScript">
		function opcao2()
			{
			document.form_lista.action="<?php echo $script_form2; ?>";
			document.forms.form_lista.submit();
			}
		</script>
		
		<script LANGUAGE="JavaScript">
		function opcao3()
			{
			document.form_lista.action="<?php echo $script_form3; ?>";
			document.forms.form_lista.submit();
			}
		</script>
		<script LANGUAGE="JavaScript">
		function opcao4()
			{
			document.form_lista.action="<?php echo $script_form4; ?>";
			document.forms.form_lista.submit();
			}
		</script>

		<script LANGUAGE="JavaScript">
		function opcao5()
			{
			document.form_lista.action="<?php echo $script_form5; ?>";
			document.forms.form_lista.submit();
			}
		</script>

		<script LANGUAGE="JavaScript">
		function opcao6()
			{
			document.form_lista.action="<?php echo $script_form6; ?>";
			document.forms.form_lista.submit();
			}
		</script>

		<script LANGUAGE="JavaScript">
		function opcao7()
			{
			document.form_lista.action="<?php echo $script_form7; ?>";
			document.forms.form_lista.submit();
			}
		</script>
	
		<table cellpadding="0" cellspacing="2" style="padding: .3em; background: none;" align="left" width="100%">
			<form method="GET" name="form_lista" target="mainFrame_bottom_listas">
			  <tr>
			  	<td width="250" valign=middle align="center"><span style="font-size:14px; color:#f90; text-transform: uppercase;"><?php echo $nomeForm; ?></span></td>
				<td align="center" width="100">
            	<?php		

				
				if($lista<=5){	
			    
				?>

				</td>
				

				<?php if($lista==5){ ?>

				<?php
				} ?>


		  		</td>
		  		<?php if($lista==4){ ?>
		  		<td align="center" width="230">
		    	<?php
			    # Faz o select do usu�rio	
				
				$query_usuario = "SELECT hospital.usuarios.*, hospital.usuarios_nivel.* FROM hospital.usuarios INNER JOIN hospital.usuarios_nivel ON hospital.usuarios_nivel.id_nivel = hospital.usuarios.nivel ORDER BY Nome";
				
				echo "<select name='ID' style=\"width:230px; vertical-align:middle; color:#666; background-color:#fff; border: 1px solid #f93; cursor:pointer; text-align: center; border-radius: 2px;\">\n";
				echo "<option value=''>Nome</option>\n";
				while ($row_usuario = mysql_fetch_array($query_usuario))
			  	echo "<option value='".$row_usuario["ID"]."'>".$row_usuario["Nome"]."</option>\n";
				echo "</select>\n";
				?>
		  		</td>
		  		<?php
				} 
				}
				?>
		  		
		  		<?php if($lista<=5){ ?>
			  	<td width="20px" align="center">
 			  	<input type="hidden" name="lista" value="<?php echo $lista ?>">
				<input type="hidden" name="enviar" value="Pesquisar">
				</td>
				<td width="80px">
				<button class="btn_cinza_escuro" onClick="opcao1()" style="cursor:pointer; vertical-align:middle; width: 80px; height: 20px;"><img src="../../imagens/most1.png" width="12" height="12" style="vertical-align:baseline; border:none;"><span style="vertical-align:baseline;">&nbsp;Mostrar lista</span>
				</button>
				</td>
				<td width="80px">
				<button class="btn_cinza_escuro" onClick="opcao2()" style="cursor:pointer; vertical-align:middle; width: 80px; height: 20px;"><img src="../../imagens/pdf2.png" width="12" height="12" style="vertical-align:baseline; border:none;"><span style="vertical-align:baseline;">&nbsp;Emitir lista</span>
				</button>
				</td>
				<td width="100px">
				<button class="btn_cinza_escuro" onClick="opcao3()" style="cursor:pointer; vertical-align:middle; width: 80px; height: 20px;"><img src="../../imagens/excel.png" width="12" height="12" style="vertical-align:baseline; border:none;"><span style="vertical-align:baseline;">&nbsp;Emitir lista</span>
				</button>
				</td>
				<?php } ?>

				 </form>
				
				<?php if($lista==5){ ?>
 				
				<?php } ?>
				<td>
				</td>
			  </tr>

		</table>
		</body>
	</html>




