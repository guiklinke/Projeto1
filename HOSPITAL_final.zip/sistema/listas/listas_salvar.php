﻿<?php
// A sessão precisa ser iniciada em cada página diferente
$nivel_necessario=0; //Inicializando variável de nível necessário para entrar nesta página
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destrói a sessão por segurança
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 


	include "../../funcoes/conecta_mysql.inc";

	$projeto = $_SESSION['projeto'];
	$id	= $_REQUEST["id"];
	$campo = strip_tags(preg_replace("/\s+/", " ", $_REQUEST["campo"]));
	$valor = strip_tags(preg_replace("/\s+/", " ", $_REQUEST["valor"]));

	# Aualiza os campos com os valores alterados
	# Aqui talvez precise alterar as funcoes em lista_alterar.js para carregar mais um campo, especificando a tabela.
	# Por hora, como praticamente todos as tabelas possuem campos com nome diferente talvez não dê problema
	# TO DO
	mysql_query("UPDATE hospital.usuarios SET $campo ='". utf8_decode($valor) ."' WHERE ID = $id",$conexao1);
    #mysql_query("UPDATE $hospital.usuarios SET $campo ='' WHERE ID = $id AND $campo ='---'",$conexao1);
    mysql_query("UPDATE hospital.usuarios_dias_escalas SET $campo ='". utf8_decode($valor) ."' WHERE user_esc_day_ID = $id",$conexao1);
    #mysql_query("UPDATE $hospital.usuarios_dias_escalas SET $campo ='' WHERE ID = $id AND $campo ='---'",$conexao1);
    mysql_query("UPDATE hospital.usuarios_escalas SET $campo ='". utf8_decode($valor) ."' WHERE user_esc_ID = $id",$conexao1);
    #mysql_query("UPDATE $hospital.usuarios_escalas SET $campo ='' WHERE ID = $id AND $campo ='---'",$conexao1);
   	
?>