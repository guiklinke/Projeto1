<?php
// A sessão precisa ser iniciada em cada página diferente
$nivel_necessario=0; //Inicializando variável de nível necessário para entrar nesta página
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destrói a sessão por segurança
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" type="text/css" href="../../funcoes/css/style_menu.css">
	<link rel="stylesheet" type="text/css" href="../../funcoes/css/style_contspi.css">
	<link rel="stylesheet" type="text/css" href="../../funcoes/css/style_thin.jquery.dataTables.min.listas.css">
	<link rel="stylesheet" type="text/css" href="../../funcoes/css/style_fixedColumns.dataTables.css">
	<style type="text/css" class="init">
	
	/* Ensure that the demo table scrolls */
	th, td { white-space: nowrap; }
	div.dataTables_wrapper {
	width: 100%;
	margin: 0 auto;
	}
	td.highlight {
	background-color: #EEEEEE !important;
	}
    body {
	/*margin-left: 10px;
	margin-right: 10px;
	margin-bottom: 10px;*/
	margin: 0px;
	background: none;
	background-color:aliceblue;
	color: #444;
	font-size: 11px;
	}
    </style>
    <script type="text/javascript" language="javascript" src="../../funcoes/js/jquery.js"></script>
	<script type="text/javascript" language="javascript" src="../../funcoes/js/jquery.dataTables.js"></script>
	<script type="text/javascript" language="javascript" src="../../funcoes/js/jquery.dataTables.fixedColumns.js"></script>
	<script type="text/javascript" language="javascript" src="../../funcoes/js/jquery.dataTables.fixedColumns.min.js"></script>
	<script type="text/javascript" language="javascript" src="../../funcoes/js/ajax.js"></script>
    <script type="text/javascript" language="javascript" src="js/listas_alterar.js"></script>
    <script type="text/javascript" language="javascript">
	function submeter(v1, v2,v3) {
		xmlhttp  = new ajax();
		xmlhttp.enviar(v1,v2,v3);
	}
	</script>
	<script type="text/javascript" language="javascript" class="init">


$(document).ready(function() {
    $('#example').DataTable( {
		"dom":'<"top"i>rt<"bottom"flp><clear>',
        scrollY:        "85vh",
        scrollX:        true,
        scrollCollapse: true,
        "paging":         false,
		"ordering":       false,
		"info":			  false,
        fixedColumns:   {
            leftColumns: 3,
			rightColumns: 1,
        }
    } );
} );
	</script>
</head>
<body>
<?php
	// ACENTUAÇÃO DA PÁGINA
	header('Content-Type: text/html; charset=ISO-8859-1');
	date_default_timezone_set('America/Sao_Paulo');
	require('../../funcoes/criarCombo.php');
	include "../../funcoes/conecta_mysql.inc";
	
	
 	$escala = filter_input(INPUT_POST, 'escala', FILTER_SANITIZE_NUMBER_INT);
	$escala_query = "SELECT inicio, fim, turno FROM escalas WHERE esc_ID = $escala";
	$result = mysql_query($escala_query,$conexao1);
	$escala_info = mysql_fetch_assoc($result);
	$start_date = new DateTime($escala_info['inicio']);
	$end_date = new DateTime($escala_info['fim']);

	$period = new DatePeriod(
	  $start_date, // 1st PARAM: start date
	  new DateInterval('P1D'), // 2nd PARAM: interval (1 day interval in this case)
	  $end_date // 3rd PARAM: end date
	);
	$mega_query = "SELECT user_esc_ID, usuarios.nome, sub_user_esc.setor_ID, sub_user_esc.entrada, sub_user_esc.saida FROM usuarios  JOIN (SELECT * FROM usuarios_escalas WHERE usuarios_escalas.esc_ID = $escala) as sub_user_esc on usuarios.ID = sub_user_esc.user_ID ORDER BY setor_ID, usuarios.nome" ;
	$funcionarios = mysql_query($mega_query,$conexao1);
	$dias_query = "SELECT user_esc_day_ID,situacao FROM (SELECT user_esc_ID, usuarios.ID, sub_user_esc.setor_ID, sub_user_esc.entrada, sub_user_esc.saida FROM usuarios  JOIN (SELECT * FROM usuarios_escalas WHERE usuarios_escalas.esc_ID = $escala) as sub_user_esc on usuarios.ID = sub_user_esc.user_ID ORDER BY setor_ID, usuarios.nome) as prev_table JOIN (SELECT* FROM usuarios_dias_escalas WHERE usuarios_dias_escalas.esc_ID = $escala ) as geral ON geral.user_ID = prev_table.ID";
	$dias = mysql_query($dias_query,$conexao1);

	$lista = 1;
	$campo = "li"; 
	$nomeForm = "Escala";
					
?>
	
<table id="example" class="stripe row-border order-column, display" cellspacing="0" cellpadding="0" width="100%" style="text-transform: uppercase;">
   <thead>
    <tr align="center" style="color: #666">
      
      <th rowspan="5" width="38" style="border-bottom: 1px solid #ccc;">Nome</th>
      <th rowspan="5"width="36" style="border-bottom: 1px solid #ccc;">Setor</th>
      <th rowspan="5"width="25"  style="border-bottom: 1px solid #ccc;">Entrada</th>  
      <th rowspan="5" width="43" style="border-bottom:1px solid #ccc">Saida</th>    
      <?php
      $day_counter = $banana;
      $day_counter=0;
      foreach ($period as $day){
       echo '<th rowspan="5" width="10" style="border-bottom: 1px solid #ccc">' . date_format($day,'d/m') . '</th>';
       $day_counter++;
      } 
      ?>  
     </tr>
   </thead>
   <tbody>
    <?php
 	
	$i = 1;
	while($row=mysql_fetch_array($funcionarios))
	{
		#$row_tipico=mysql_fetch_array($sql_tipico);
		#echo $row_tipico[69];
	$id = $row[0];

	?>   
    	<tr align="center" style="text-transform: uppercase; cursor: pointer;" <?php echo $row[0]; ?>', 'mainFrame_bottom')">

			<td><?php altera_dado($row[1], "nome" ,$i,-1,3,2,1) #Talvez esse campo nao deva permitir alterar ?></td><?php echo "\n"; $i++; ?> 
			<td>
			<select name="Setor <?php echo $row[2]?>" class="doc_select" style="color: #000; font-size: 11px; text-transform: uppercase;" onChange=<?php echo "\"submeter('listas_salvar.php?id=" . $id . "&campo=setor_ID&valor=' + this.value, 'POST', false)\""; ?>>
			<?php criarComboEditar("hospital.setores",0,1,$row[2],"Nome_setor");?>
			</select>
			</td>
			<!-- <td><?php altera_dado($row[2], "Nome_setor",$i,$id,3,2,1) ?></td><?php echo "\n"; $i++; ?> -->
			<td><?php altera_dado($row[3], "entrada" ,$i,$id,3,2,1) ?></td><?php echo "\n"; $i++; ?>
			<td><?php altera_dado($row[4], "saida",$i,$id,3,2,1) ?></td><?php echo "\n"; $i++; 
		    for($j=0;$j<$day_counter;$j++){
		        $dias_row = mysql_fetch_array($dias);?>
		        <td><?php altera_dado($dias_row[1],"situacao",$i,$dias_row[0],3,2,1) ?></td><?php echo "\n"; $i++; 
		        #alterar os metadados da funcao
		    }
		    ?> 
        </tr>
    <?php } ?>
   </tbody>
</table>
</body>
</html>
