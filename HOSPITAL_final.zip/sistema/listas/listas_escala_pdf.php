<?php
// A sessão precisa ser iniciada em cada página diferente
$nivel_necessario=0; //Inicializando variável de nível necessário para entrar nesta página
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destrói a sessão por segurança
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 

/***************************************************************************
DESCRIÇÃO .......: Gerando um PDF utilizando banco de dados MySQL
****************************************************************************/
header('Content-Type: text/html; charset=ISO-8859-1');

//ENDEREÇO DA BIBLIOTECA FPDF                             
$end_fpdf    =  "../../funcoes/fpdf";              

//NUMERO DE RESULTADOS POR PÁGINA                         
$por_pagina  =  16;                                       

//TIPO DO PDF GERADO                                      
//F-> SALVA NO ENDEREÇO ESPECIFICADO NA VAR END_FINAL     
$tipo_pdf    =  "F";                                      

//FAZ A CONEXÃO COM O BANCO DE DADOS
include "../../funcoes/conecta_mysql.inc";


# SELECIONA A INSTRUMENTOS CONFORME PRÉDIO, SISTEMA E LISTA 

#CONSIDERA QUE A ESCOLHA DA ESCALA VEIO DE UM POST
$escala = filter_input(INPUT_POST, 'escala', FILTER_SANITIZE_NUMBER_INT);
$escala_query = "SELECT inicio, fim, turno FROM escalas WHERE esc_ID = $escala";
$result = mysql_query($escala_query,$conexao1);
$escala_info = mysql_fetch_assoc($result);
$start_date = new DateTime($escala_info['inicio']);
$end_date = new DateTime($escala_info['fim']);

$period = new DatePeriod(
  $start_date, // 1st PARAM: start date
  new DateInterval('P1D'), // 2nd PARAM: interval (1 day interval in this case)
  $end_date // 3rd PARAM: end date
);

$mega_query = "SELECT usuarios.nome,setores.Nome_setor, sub_user_esc.setor_ID, sub_user_esc.entrada, sub_user_esc.saida FROM usuarios JOIN ((SELECT * FROM usuarios_escalas WHERE usuarios_escalas.esc_ID = $escala) as sub_user_esc JOIN setores ON sub_user_esc.setor_ID = setores.setor_ID) ON usuarios.ID = sub_user_esc.user_ID  ORDER BY setores.Nome_setor, usuarios.nome" ;
$funcionarios = mysql_query($mega_query,$conexao1);
$dias_query = "SELECT user_esc_day_ID,situacao FROM (SELECT usuarios.ID, usuarios.nome,setores.Nome_setor FROM usuarios JOIN ((SELECT * FROM usuarios_escalas WHERE usuarios_escalas.esc_ID = $escala) as sub_user_esc JOIN setores ON sub_user_esc.setor_ID = setores.setor_ID) ON usuarios.ID = sub_user_esc.user_ID ORDER BY setores.Nome_setor, usuarios.nome) as prev_table JOIN (SELECT* FROM usuarios_dias_escalas WHERE usuarios_dias_escalas.esc_ID = $escala ) as geral ON geral.user_ID = prev_table.ID";
$dias = mysql_query($dias_query,$conexao1);
$row =  mysql_num_rows($funcionarios); 

//VERIFICA SE RETORNOU ALGUMA LINHA
if(!$row) { echo "Não retornou nenhum registro **"; die; }

//CALCULA QUANTAS PÁGINAS VÃO SER NECESSÁRIAS
       
$paginas   =  ceil(($row/$por_pagina));
define("FPDF_FONTPATH", "$end_fpdf/font/");
require('../../funcoes/fpdf/cellpdf.php');

$pdf=new CellPDF("L","mm","A4");
//$pdf->SetMargins(14,10,5,1.0);
$pdf->SetMargins(19,25,0.5,1.0);
$pdf->SetAutoPageBreak(true,1.0);
//$pdf->addPage();
$pdf->SetFont('Arial','',8);
$pdf->SetFillColor(255,255,255);



//INICIALIZA AS VARIÁVEIS
$linha_atual =  0;
$linha_dia   =  0;
$inicio      =  0;

//PÁGINAS
for($x=1; $x<=$paginas; $x++) {
   //VERIFICA
   $inicio      =  $linha_atual;
   $fim         =  $linha_atual + $por_pagina;
   if($fim > $row) $fim = $row;

	$pdf->AddPage();
	$pdf->SetFont('Arial','',12);
   	$pdf->SetFillColor(255,255,255);
    $y1=$pdf->GetY();
	$pdf->image('../../imagens/logo.png',13,$y1-25,30,23,'PNG');
	$y1=$pdf->GetY();
	$pdf->image('../../imagens/spdm.png',255,$y1-25,23,25,'PNG');
    $pdf->SetFont('Arial','B',10);
	$pdf->SetFillColor(220); // Preenche celula com cor cinza claro
	$pdf->Cell(30,10,'NOME','BTLR',0,'C', true);// true - ativa a cor da celula
	$pdf->Cell(20,10,'SETOR','BTLR',0,'C', true);
	$pdf->Cell(10,10,"ENTRADA",'BTLR',0,'C', true);
	$pdf->Cell(10,10,"SAIDA",'BTLR',0,'C', true);
	$day_counter=0;
	foreach ($period as $day){
		$pdf->Cell(10,10,date_format($day,'d/m'),'BTLR',0,'C', true);
	$day_counter++;
	} 
	//$pdf->Ln(10);
	//$pdf->cell(199);
	$pdf->SetFont('Arial','',10);
	$pdf->Ln();

   //EXIBE OS REGISTROS      
   for($i=$inicio; $i<$fim; $i++) {
	   
	$pdf->SetFont('Arial','',10);
	$pdf->Cell(30,10,mysql_result($funcionarios, $i, "nome"),1,0,'C'); #3
	$pdf->Cell(20,10,mysql_result($funcionarios, $i, "Nome_setor"),1,0,'C'); #4
	$pdf->Cell(10,10,mysql_result($funcionarios, $i, "entrada"),1,0,'C'); #3
	$pdf->Cell(10,10,mysql_result($funcionarios, $i, "saida"),1,0,'C'); #4
	for($j=0;$j<$day_counter;$j++){
		$pdf->Cell(10,10,mysql_result($dias, $linha_dia, "situacao"),1,0,'C');
        $linha_dia++;
        #alterar os metadados da funcao
	}
	$pdf->Ln();
	$linha_atual++;
	
	
   }//FECHA FOR(REGISTROS - i) 
  //$pdf->SetMargins(14,25,10,1.0);
 
}//FECHA FOR(PAGINAS - x)

//SAIDA DO PDF
$pdf->Output();
?>
