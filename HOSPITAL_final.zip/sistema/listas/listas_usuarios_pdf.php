<?php
// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();

$nivel_necessario == 3+1;

// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
} 

/***************************************************************************
DESCRI��O .......: Gerando um PDF utilizando banco de dados MySQL
****************************************************************************/
header('Content-Type: text/html; charset=ISO-8859-1');

//ENDERE�O DA BIBLIOTECA FPDF                             
$end_fpdf    =  "../../funcoes/fpdf";              

//NUMERO DE RESULTADOS POR P�GINA                         
$por_pagina  =  16;                                       

//TIPO DO PDF GERADO                                      
//F-> SALVA NO ENDERE�O ESPECIFICADO NA VAR END_FINAL     
$tipo_pdf    =  "F";                                      

//FAZ A CONEX�O COM O BANCO DE DADOS
include "../../funcoes/conecta_mysql.inc";


# SELECIONA A INSTRUMENTOS CONFORME PR�DIO, SISTEMA E LISTA 

$sql = mysql_query("SELECT hospital.usuarios.*, hospital.usuarios_nivel.* FROM hospital.usuarios INNER JOIN hospital.usuarios_nivel ON hospital.usuarios_nivel.id_nivel = hospital.usuarios.nivel ORDER BY Nome");
	
$row =  mysql_num_rows($sql); 

//VERIFICA SE RETORNOU ALGUMA LINHA
if(!$row) { echo "N�o retornou nenhum registro **"; die; }

//CALCULA QUANTAS P�GINAS V�O SER NECESS�RIAS
       
$paginas   =  ceil(($row/$por_pagina));
define("FPDF_FONTPATH", "$end_fpdf/font/");
require('../../funcoes/fpdf/cellpdf.php');

$pdf=new CellPDF("L","mm","A4");
//$pdf->SetMargins(14,10,5,1.0);
$pdf->SetMargins(19,25,0.5,1.0);
$pdf->SetAutoPageBreak(true,1.0);
//$pdf->addPage();
$pdf->SetFont('Arial','',8);
$pdf->SetFillColor(255,255,255);



//INICIALIZA AS VARI�VEIS
$linha_atual =  0;
$inicio      =  0;

//P�GINAS
for($x=1; $x<=$paginas; $x++) {
   //VERIFICA
   $inicio      =  $linha_atual;
   $fim         =  $linha_atual + $por_pagina;
   if($fim > $row) $fim = $row;

	$pdf->AddPage();
	$pdf->SetFont('Arial','',12);
   	$pdf->SetFillColor(255,255,255);
    $y1=$pdf->GetY();
	$pdf->image('../../imagens/logo.png',13,$y1-25,30,23,'PNG');
	$y1=$pdf->GetY();
	$pdf->image('../../imagens/spdm.png',255,$y1-25,23,25,'PNG');
    $pdf->SetFont('Arial','B',10);
	$pdf->SetFillColor(220); // Preenche celula com cor cinza claro
	$pdf->Cell(100,10,'NOME','BTLR',0,'C', true);// true - ativa a cor da celula
	$pdf->Cell(32,10,'V�NCULO','BTLR',0,'C', true);
	$pdf->Cell(32,10,"RF/RE",'BTLR',0,'C', true);
	$pdf->Cell(32,10,"CATEGORIA",'BTLR',0,'C', true);
	$pdf->Cell(32,10,"COREN",'BTLR',0,'C',true);
	$pdf->Cell(32,10,"NOME DO\nSETOR",'BTLR',0,'C', true);	
	//$pdf->Ln(10);
	//$pdf->cell(199);
	$pdf->SetFont('Arial','',10);
	$pdf->Ln();

   //EXIBE OS REGISTROS      
   for($i=$inicio; $i<$fim; $i++) {
	   
	$pdf->SetFont('Arial','',10);
	$pdf->Cell(100,10,mysql_result($sql, $i, "Nome"),1,0,'C'); #3
	$pdf->Cell(32,10,mysql_result($sql, $i, "Vinculo"),1,0,'C'); #4
	$pdf->Cell(32,10,mysql_result($sql, $i, "Referencia"),1,0,'C'); #3
	$pdf->Cell(32,10,mysql_result($sql, $i, "Categoria"),1,0,'C'); #4
	$pdf->Cell(32,10,mysql_result($sql, $i, "Coren"),1,0,'C'); #5
	$pdf->Cell(32,10,mysql_result($sql, $i, "Nome_setor"),1,0,'C'); #5	
	
	$pdf->Ln();
	$linha_atual++;
	
	
   }//FECHA FOR(REGISTROS - i) 
  //$pdf->SetMargins(14,25,10,1.0);
 
}//FECHA FOR(PAGINAS - x)

//SAIDA DO PDF
$pdf->Output();
?>
