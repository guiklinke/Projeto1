﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" HREF="logo.png">
<style type="text/css">
body {
	
	
}
</style>
<title>Listas</title>
</head>
<frameset rows="30,*" border="0">
<frame src="listas_pesquisa.php?nomeLista=<?php echo $_GET["nomeLista"]; ?>" name="mainFrame_top_listas" scrolling="NO" noresize style="background: none;">
<frame src="" name="mainFrame_bottom_listas" style="background: none;">
</frameset><noframes></noframes> 
</HTML>