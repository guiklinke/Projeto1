-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 04-Fev-2021 às 01:28
-- Versão do servidor: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `dias`
--

CREATE TABLE IF NOT EXISTS `dias` (
  `Dia` date NOT NULL,
  `EscalaTurno` varchar(255) NOT NULL,
  `EscalaPeriodo` date NOT NULL,
  `Dia_tipo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Dia`,`EscalaTurno`),
  KEY `FKDias246823` (`EscalaPeriodo`,`EscalaTurno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `escala`
--

CREATE TABLE IF NOT EXISTS `escala` (
  `Periodo` date NOT NULL,
  `Turno` varchar(255) NOT NULL,
  PRIMARY KEY (`Periodo`,`Turno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `setores`
--

CREATE TABLE IF NOT EXISTS `setores` (
  `Setor_ID` int(10) NOT NULL AUTO_INCREMENT,
  `Nome_setor` varchar(255) NOT NULL,
  `Numero_minimo_de_pessoas` int(10) DEFAULT NULL,
  `Setor_ativo` int(1) NOT NULL,
  PRIMARY KEY (`Setor_ID`),
  UNIQUE KEY `Nome_setor` (`Nome_setor`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `setores`
--

INSERT INTO `setores` (`Setor_ID`, `Nome_setor`, `Numero_minimo_de_pessoas`, `Setor_ativo`) VALUES
(1, 'DI', NULL, 1),
(2, 'DII', NULL, 1),
(3, 'SNI', NULL, 1),
(4, 'SNII', NULL, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(255) NOT NULL,
  `Login` varchar(50) NOT NULL,
  `Senha` varchar(50) NOT NULL,
  `Coren` int(10) DEFAULT NULL,
  `Categoria` varchar(255) DEFAULT NULL,
  `Referencia` varchar(255) DEFAULT NULL,
  `Vinculo` varchar(255) DEFAULT NULL,
  `Nome_setor` varchar(255) NOT NULL,
  `Nivel` int(1) unsigned NOT NULL DEFAULT '1',
  `ativo` tinyint(4) NOT NULL DEFAULT '1',
  `Setor_ID` int(10) NOT NULL,
  `data_acesso` date NOT NULL,
  `hora_acesso` time NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Nome` (`Nome`),
  UNIQUE KEY `Coren` (`Coren`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=76 ;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`ID`, `Nome`, `Login`, `Senha`, `Coren`, `Categoria`, `Referencia`, `Vinculo`, `Nome_setor`, `Nivel`, `ativo`, `Setor_ID`, `data_acesso`, `hora_acesso`) VALUES
(1, 'Rapha', 'RA', '1234', 123, 'categoria', 'Ref', 'vinculo', 'SNI', 3, 1, 1, '0000-00-00', '00:00:00'),
(2, 'Sergio', 'SA', '1234', 2222, 'Categoria', 'Referencia', 'Vinculo', 'DI', 3, 1, 4, '0000-00-00', '00:00:00'),
(3, 'Meire', 'me', '2525', NULL, 'CATEG', NULL, NULL, '', 3, 1, 0, '0000-00-00', '00:00:00'),
(4, 'yuri', 'yu', '1234', NULL, 'CAT', 'REF', NULL, '', 1, 1, 0, '0000-00-00', '00:00:00'),
(5, 'beatriz', 'biA', '1236', 11, 'CATEGORIA', 'IAS', NULL, 'SETOR', 2, 1, 0, '0000-00-00', '00:00:00'),
(6, 'karla', 'ka', '1234', NULL, NULL, NULL, NULL, 'SETOR', 1, 1, 0, '0000-00-00', '00:00:00'),
(7, 'tatu', 'ta', '1234', NULL, NULL, NULL, NULL, '', 1, 1, 0, '0000-00-00', '00:00:00'),
(8, 'orla', 'or', '1234', 0, 'CAT', 'REF', NULL, '', 1, 1, 0, '0000-00-00', '00:00:00'),
(10, 'yor', 'y', '1234', NULL, NULL, NULL, NULL, '', 1, 1, 0, '0000-00-00', '00:00:00'),
(11, 'opkl', 'o', '1234', NULL, NULL, NULL, NULL, '', 2, 1, 0, '0000-00-00', '00:00:00'),
(12, 'rer', 'r', '1234', NULL, NULL, NULL, NULL, '', 1, 1, 0, '0000-00-00', '00:00:00'),
(13, 'pato', 'qua', '1234', 12345, NULL, NULL, NULL, '', 1, 1, 0, '0000-00-00', '00:00:00'),
(15, 'gato', 'ga', '1234', 6777, NULL, NULL, NULL, 'SETOR', 1, 1, 0, '0000-00-00', '00:00:00'),
(16, 'onca', 'on', '1234', 77788, NULL, NULL, NULL, '', 3, 1, 0, '0000-00-00', '00:00:00'),
(17, 'lato', 'la', '1234', 8888, 'enfermeira', 'REFERENCIAS', 'permanente', 'enfermaria', 1, 1, 0, '0000-00-00', '00:00:00'),
(18, 'RRARR', 'FSAFf', '1234', 1111, 'ffsaf', 'fsfa', 'Ffa', 'fFS', 1, 1, 0, '0000-00-00', '00:00:00'),
(20, 'SSSS', 'SSS', '1234', 111, 'SSS', 'SSS', 'SSS', 'SS', 1, 1, 0, '0000-00-00', '00:00:00'),
(23, 'YYY', 'YYY', '1234', 222, 'YYY', 'YYY', 'YY', 'YY', 2, 1, 0, '0000-00-00', '00:00:00'),
(40, '7777', '77', '1234', 77, '77', '77', '77', '77', 1, 1, 0, '0000-00-00', '00:00:00'),
(41, '888', '88', '1234', 88, '88', '88', '88', '88', 3, 1, 0, '0000-00-00', '00:00:00'),
(45, '2222', '22', '1234', 22, '22', '22', '22', '22', 1, 1, 0, '0000-00-00', '00:00:00'),
(46, 'TTT', '55', '1234', 55, 'TT', 'TT', 'TT', 'TT', 1, 1, 0, '0000-00-00', '00:00:00'),
(54, 'RRR', 'RR', '1234', 1111111, 'DD', 'DD', 'DD', 'RRRR', 1, 1, 0, '0000-00-00', '00:00:00'),
(55, '4444', '44', '1234', 44, '44', '44', 'cccccc', 'R', 1, 1, 0, '0000-00-00', '00:00:00'),
(58, '33', '33', '1234', 33, '33', '33', '33', '33', 1, 1, 0, '0000-00-00', '00:00:00'),
(59, '999', '99', '1234', 99, '99', '99', '99', '99', 1, 1, 0, '0000-00-00', '00:00:00'),
(62, '8888888', '8888', '1234', 888, '888', '88', '88', '88', 1, 1, 0, '0000-00-00', '00:00:00'),
(64, 'TESTE', 'TE', '1234', 453, '33', '33', '33', '33', 1, 1, 0, '0000-00-00', '00:00:00'),
(65, 'MARIA', '444', '1234', 123456, 'D', 'D', 'D', 'D', 1, 1, 0, '0000-00-00', '00:00:00'),
(66, 'TESTANDO', '11', '1234', 86141, 'Q', 'Q', 'Q', 'Q', 1, 1, 0, '0000-00-00', '00:00:00'),
(67, '776655', '1234', '1234', 89, 'C', 'C', 'C', 'C', 1, 1, 0, '0000-00-00', '00:00:00'),
(68, 'BBBB', 'BB', '1234', 987654, 'C', 'C', 'C', 'V', 1, 1, 0, '0000-00-00', '00:00:00'),
(69, 'ASDFGHJKLÇ', '11', '1234', 7777, '1', '1', '1', '1', 1, 1, 0, '0000-00-00', '00:00:00'),
(70, 'WWWWW', 'WW', '1234', 545454, 'C', 'C', 'C', 'C', 1, 1, 0, '0000-00-00', '00:00:00'),
(71, 'mmmmmmm', 'mm', '1234', 2147483647, '1', 'f', 'f', 'f', 1, 1, 0, '0000-00-00', '00:00:00'),
(72, 'cccccc', 'dd', '1234', 7654321, 'rr', 'rr', 'rr', 'rr', 1, 1, 0, '0000-00-00', '00:00:00'),
(74, 'usuario', 'ta', '1234', 465895, 'enada', '89955', 'enfermagem', 'enfermaria', 1, 1, 0, '0000-00-00', '00:00:00'),
(75, 'gaga', 'ga', '1234', 4693331, 'enfermeira', '222234', 'enfermeira', 'enfermaria', 3, 1, 0, '0000-00-00', '00:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios_dias`
--

CREATE TABLE IF NOT EXISTS `usuarios_dias` (
  `UsuariosRF` int(10) NOT NULL,
  `DiasDia` date NOT NULL,
  `DiasEscalaTurno` varchar(255) NOT NULL,
  `Presenca` binary(1) DEFAULT NULL,
  `Situacao` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`UsuariosRF`,`DiasDia`,`DiasEscalaTurno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios_escala`
--

CREATE TABLE IF NOT EXISTS `usuarios_escala` (
  `UsuariosRF` int(10) NOT NULL,
  `EscalaPeriodo` date NOT NULL,
  `EscalaTurno` varchar(255) NOT NULL,
  `Hora_entrada` time DEFAULT NULL,
  `Hora_saida` time DEFAULT NULL,
  PRIMARY KEY (`UsuariosRF`,`EscalaPeriodo`,`EscalaTurno`),
  KEY `FKUsuarios_E436495` (`EscalaPeriodo`,`EscalaTurno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios_nivel`
--

CREATE TABLE IF NOT EXISTS `usuarios_nivel` (
  `id_nivel` int(10) NOT NULL AUTO_INCREMENT,
  `Desc_nivel` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_nivel`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `usuarios_nivel`
--

INSERT INTO `usuarios_nivel` (`id_nivel`, `Desc_nivel`) VALUES
(1, 'Visual'),
(2, 'Usuario'),
(3, 'Admin');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios_setores`
--

CREATE TABLE IF NOT EXISTS `usuarios_setores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Setor_ID` int(5) NOT NULL,
  `id_usuario` int(5) NOT NULL,
  `autoriza_setor` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `dias`
--
ALTER TABLE `dias`
  ADD CONSTRAINT `FKDias246823` FOREIGN KEY (`EscalaPeriodo`, `EscalaTurno`) REFERENCES `escala` (`Periodo`, `Turno`);

--
-- Limitadores para a tabela `usuarios_escala`
--
ALTER TABLE `usuarios_escala`
  ADD CONSTRAINT `FKUsuarios_E436495` FOREIGN KEY (`EscalaPeriodo`, `EscalaTurno`) REFERENCES `escala` (`Periodo`, `Turno`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
