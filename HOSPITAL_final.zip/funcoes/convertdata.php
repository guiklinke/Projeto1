<?php
function mes($texto){
    $_texto_para_mes = array(
         1 =>'Jan',
         2 =>'Fev',
         3 =>'Mar',
         4 =>'Abr',
         5 =>'Mai',
         6 =>'Jun',
         7 =>'Jul',
         8 =>'Ago',
         9 =>'Set',
         10 =>'Out',
         11 =>'Nov',
         12 =>'Dez',
    );
    return $_texto_para_mes[$texto];
    }

function moeda($get_valor) {
		$source = array('.', ',',','); 
		$replace = array('', '.');
		$valor = str_replace($source, $replace, $get_valor); //remove os pontos e substitui a virgula pelo ponto
		return $valor; //retorna o valor formatado para gravar no banco
	}

function ConverteData($Data){
	if (strstr($Data, "/"))//verifica se tem a barra /
 		{  $d = explode ("/", $Data);//tira a barra
 			$rstData = "$d[2]-$d[1]-$d[0]";//separa as datas $d[2] = ano $d[1] = mes etc...
			 return $rstData;
 		} elseif(strstr($Data, "-")){
			$d = explode ("-", $Data);
    		$rstData = "$d[2]/$d[1]/$d[0]"; 
 			return $rstData;
		}else{
 			return "Data invalida";
		}
 		}
		
function dias_uteis($datainicial,$datafinal=null){
  if (!isset($datainicial)) return false;
  $segundos_datainicial = strtotime(str_replace("/","-",$datainicial));
  if (!isset($datafinal)) $segundos_datafinal=time();
  else $segundos_datafinal = strtotime(str_replace("/","-",$datafinal));
  $dias = abs(floor(floor(($segundos_datafinal-$segundos_datainicial)/3600)/24 ) );
  $uteis=0;
  for($i=1;$i<=$dias;$i++)
  {
    $diai = $segundos_datainicial+($i*3600*24);
    $w = date('w',$diai);
    if ($w>0 && $w<6){ $uteis++; }
  }
  return $uteis;
}

function dateDiff($sDataInicial, $sDataFinal)
{
	$sDataI = explode("-", $sDataInicial);
	$sDataF = explode("-", $sDataFinal);
	
	$nDataInicial = mktime(0, 0, 0, $sDataI[1], $sDataI[0], $sDataI[2]);
	$nDataFinal = mktime(0, 0, 0, $sDataF[1], $sDataF[0], $sDataF[2]);
	return ($nDataInicial > $nDataFinal) ?
	floor(($nDataInicial - $nDataFinal)/86400) : floor(($nDataFinal - $nDataInicial)/86400);
}

