<?php

function mask($val, $mask)
{
 $maskared = '';
 $k = 0;
 for($i = 0; $i<=strlen($mask)-1; $i++)
 {
 if($mask[$i] == '#')
 {
 if(isset($val[$k]))
 $maskared .= $val[$k++];
 }
 else
 {
 if(isset($mask[$i]))
 $maskared .= $mask[$i];
 }
 }
 return $maskared;
}

include "conecta_mysql.inc";

function formataDataHora($dDataHora, $sFormato){
     return date($sFormato,strtotime($dDataHora));
}

function altera_dado_OLD($item_busca,$campo_busca,$i,$id){
			if($item_busca!=""){
			echo "<span ID=\"campo$i\"><span onclick=\"editar($i,this,$id,'".$campo_busca."');\">".$item_busca."</span></span>";
			}else{
			echo "<span ID=\"campo$i\"><span onclick=\"editar($i,this,$id,'$campo_busca');\">---</span></span>";
			}
}

function altera_dado($item_busca, $campo_busca, $i, $id, $usu1, $usu2, $tipo_campo, $tb){
	# $item_busca -> dado a ser encontrado
	# $campo_busca -> campo a ser pesquisado
	# $i da fun��o
	# $id -> id do registro
	# $usu1 e $usu2 -> nivel dos usu�rios
	# $tipo_campo -> 1=normal  2=data  3=valor
	# $tb -> nome da tabela para salvar os dados
	
	
	if ($_SESSION['UsuarioNivel']==$usu1 || $_SESSION['UsuarioNivel']==$usu2){ 
		
		# mostra campo sem formata��o
		if ($tipo_campo==1 AND $item_busca !='') {echo "<span ID=\"campo$i\"><span style=\"cursor: pointer;\" onMouseOver=\"javascript:this.style.color='#69c'\" onMouseOut=\"javascript:this.style.color=''\" onclick=\"editar($i,this,$id,'".$campo_busca."','".$tb."');\">".$item_busca."</span></span>";}
		
		# mostra com a format��o de data
		elseif ($tipo_campo==2 AND $item_busca >0) {echo "<span ID=\"campo$i\"><span style=\"cursor: pointer;\" onMouseOver=\"javascript:this.style.color='#69c'\" onMouseOut=\"javascript:this.style.color=''\" onclick=\"editar($i,this,$id,'".$campo_busca."','".$tb."');\">".date("d/m/Y",strtotime($item_busca))."</span></span>";} 
		
		# mostra com a formata��o de valor
		elseif ($tipo_campo==3 AND $item_busca >0) {echo "<span ID=\"campo$i\"><span style=\"cursor: pointer;\" onMouseOver=\"javascript:this.style.color='#69c'\" onMouseOut=\"javascript:this.style.color=''\" onclick=\"editar($i,this,$id,'".$campo_busca."','".$tb."');\">".number_format($item_busca,2,",",".")."</span></span>";} 
		
		# Se o valor for '' (vazio) mostra '---' para edi��o do dado
		else echo "<span ID=\"campo$i\"><span style=\"cursor: pointer; color: #ccc;\" onclick=\"editar($i,this,$id,'".$campo_busca."','".$tb."');\">---</span></span>";
	}else{
		if ($tipo_campo == 1 AND $item_busca !='') {echo $item_busca;}
		elseif ($tipo_campo == 2 AND $item_busca >0) {echo date("d/m/Y",strtotime($item_busca));}
		elseif ($tipo_campo == 3 AND $item_busca >0) {echo number_format($item_busca,2,",",".");}
	}
}

function criarCombo($table,$id,$valor,$indice,$condicao)
{
	   $sql = "SELECT * FROM ".$table." ".$condicao." ORDER BY $indice";
	   $rs_sql = mysql_query($sql);
	   $corlinha=0;
	   $combo=0;
	   while($linha=mysql_fetch_array($rs_sql))   
	   {     
	  	    $corlinha++;
	   		$chave = $linha[$id];
	        $nome  = $linha[$valor]; 
			if ($corlinha % 2 == 0){ $cor="impar"; } else { $cor="par"; }
			$combo = $combo . "<option value=\"$chave\" class=\"$cor\">$nome</option>";   
	   }
	   echo $combo;}

function criarComboDuplo($table,$id,$valor1,$valor2,$separador,$indice)
{
	   $sql = "SELECT * FROM ".$table." ORDER BY $indice";
	   $rs_sql = mysql_query($sql);
	   $corlinha=0;
	   $combo=0;
	   while($linha=mysql_fetch_row($rs_sql))   
	   {     
	  	    $corlinha++;
	   		$chave = $linha[$id];
	        $nome  = $linha[$valor1]; 
	        $nome2 = $linha[$valor2]; 
			if ($corlinha % 2 == 0){ $cor="impar"; } else { $cor="par"; }
			$combo = $combo . "<option value=\"$chave\" class=\"$cor\">$nome $separador $nome2</option>";			
	   }
	   echo $combo;}
 
function criarComboEditar($table,$id,$valor1,$compara,$indice)
{
	   $sql = "SELECT * FROM ".$table." ".$condicao." ORDER BY $indice";
	   $rs_sql = mysql_query($sql);
	   $corlinha=0;
	   $combo=0;
	   while($linha=mysql_fetch_row($rs_sql))   
	   {     
	  	    $corlinha++;
	   		$chave = $linha[$id];
	        $nome  = $linha[$valor1]; 
			if ($chave==$compara) {$selecionar='selected';} else {$selecionar='';}
			if ($corlinha % 2 == 0){ $cor="impar"; } else { $cor="par"; }
			$combo = $combo . "<option value=\"$chave\" class=\"$cor\" $selecionar title=\"$nome\">$nome</option>";			
	   }
	   echo $combo;}

function criarComboEditarTipicoPRO($table,$id,$valor1,$compara,$indice)
{

	   $sql = "SELECT * FROM ".$table." WHERE nome_tipico LIKE 'PRO%' ORDER BY $indice";
	   $rs_sql = mysql_query($sql);
	   $corlinha=0;
	   $combo=0;
	   while($linha=mysql_fetch_row($rs_sql))   
	   {     
	  	    $corlinha++;
	   		$chave = $linha[$id];
	        $nome  = $linha[$valor1]; 
			if ($chave==$compara) {$selecionar='selected';} else {$selecionar='';}
			if ($corlinha % 2 == 0){ $cor="impar"; } else { $cor="par"; }
			$combo = $combo . "<option value=\"$chave\" class=\"$cor\" $selecionar title=\"$nome\">$nome</option>";			
	   }
	   echo $combo;}

function criarComboEditarTipicoELE($table,$id,$valor1,$compara,$indice)
{

	   $sql = "SELECT * FROM ".$table." WHERE nome_tipico LIKE 'ELE%' ORDER BY $indice";
	   $rs_sql = mysql_query($sql);
	   $corlinha=0;
	   $combo=0;
	   while($linha=mysql_fetch_row($rs_sql))   
	   {     
	  	    $corlinha++;
	   		$chave = $linha[$id];
	        $nome  = $linha[$valor1]; 
			if ($chave==$compara) {$selecionar='selected';} else {$selecionar='';}
			if ($corlinha % 2 == 0){ $cor="impar"; } else { $cor="par"; }
			$combo = $combo . "<option value=\"$chave\" class=\"$cor\" $selecionar title=\"$nome\">$nome</option>";			
	   }
	   echo $combo;}

function criarComboEditarTipicoJBSUP($table,$id,$valor1,$compara,$indice)
{

	   $sql = "SELECT * FROM ".$table." WHERE nome_tipico LIKE 'JB%' OR nome_tipico LIKE 'SUP%'  ORDER BY $indice";
	   $rs_sql = mysql_query($sql);
	   $corlinha=0;
	   $combo=0;
	   while($linha=mysql_fetch_row($rs_sql))   
	   {     
	  	    $corlinha++;
	   		$chave = $linha[$id];
	        $nome  = $linha[$valor1]; 
			if ($chave==$compara) {$selecionar='selected';} else {$selecionar='';}
			if ($corlinha % 2 == 0){ $cor="impar"; } else { $cor="par"; }
			$combo = $combo . "<option value=\"$chave\" class=\"$cor\" $selecionar title=\"$nome\">$nome</option>";			
	   }
	   echo $combo;}

function criarComboEditarTipicoPNM($table,$id,$valor1,$compara,$indice)
{

	   $sql = "SELECT * FROM ".$table." WHERE nome_tipico LIKE 'PNM%' ORDER BY $indice";
	   $rs_sql = mysql_query($sql);
	   $corlinha=0;
	   $combo=0;
	   while($linha=mysql_fetch_row($rs_sql))   
	   {     
	  	    $corlinha++;
	   		$chave = $linha[$id];
	        $nome  = $linha[$valor1]; 
			if ($chave==$compara) {$selecionar='selected';} else {$selecionar='';}
			if ($corlinha % 2 == 0){ $cor="impar"; } else { $cor="par"; }
			$combo = $combo . "<option value=\"$chave\" class=\"$cor\" $selecionar title=\"$nome\">$nome</option>";			
	   }
	   echo $combo;}

function criarComboEditarTipicoSUP($table,$id,$valor1,$compara,$indice)
{

	   $sql = "SELECT * FROM ".$table." WHERE nome_tipico LIKE 'SUP%' ORDER BY $indice";
	   $rs_sql = mysql_query($sql);
	   $corlinha=0;
	   $combo=0;
	   while($linha=mysql_fetch_row($rs_sql))   
	   {     
	  	    $corlinha++;
	   		$chave = $linha[$id];
	        $nome  = $linha[$valor1]; 
			if ($chave==$compara) {$selecionar='selected';} else {$selecionar='';}
			if ($corlinha % 2 == 0){ $cor="impar"; } else { $cor="par"; }
			$combo = $combo . "<option value=\"$chave\" class=\"$cor\" $selecionar title=\"$nome\">$nome</option>";			
	   }
	   echo $combo;}


function criarComboEditarDuplo($table,$id,$valor1,$valor2,$separador,$compara,$indice)
{
	   $sql = "SELECT * FROM ".$table." ORDER BY " . $indice;
	   $rs_sql = mysql_query($sql);
	   $corlinha=0;
	   $combo=0;
	   while($linha=mysql_fetch_row($rs_sql))   
	   {     
	  	    $corlinha++;
	   		$chave = $linha[$id];
	        $nome  = $linha[$valor1]; 
	        $nome2 = $linha[$valor2]; 
			if ($chave==$compara) {$selecionar='selected';} else {$selecionar='';}
			if ($corlinha % 2 == 0){ $cor="impar"; } else { $cor="par"; }
			$combo = $combo . "<option value=\"$chave\" class=\"$cor\" $selecionar>$nome $separador $nome2</option>";			
	   }
	   echo $combo;}

?>

