<?php
	# Conecta com a base de dados
	include "funcoes/conecta_mysql.inc";
	$sql=$_REQUEST["sql"];
	
	$query = mysql_query($sql);
	
	# Salva os dados encontados na vari�vel $resultado
	$resultado = mysql_fetch_assoc($query);

	// Se a sess�o n�o existir, inicia uma
	if (!isset($_SESSION)) session_start($query);

	// Salva os dados encontrados na sess�o
	$_SESSION['UsuarioID'] = $resultado['ID'];
	$_SESSION['UsuarioNome'] = $resultado['Nome'];
	$_SESSION['Login'] = $resultado['Login'];
	$_SESSION['UsuarioSenha'] = $resultado['Senha'];
	$_SESSION['UsuarioNivel'] = $resultado['Nivel'];
	
	
	$hora=date("H:i:s");
	$dataAtual = date("Y-m-d");
	
	mysql_query("UPDATE hospital.usuarios SET data_acesso='".$dataAtual."', hora_acesso='".$hora."' WHERE id=".$_SESSION['UsuarioID']);
	header("Location: menu_projetos.php?sql=".$sql); exit;
	
?>