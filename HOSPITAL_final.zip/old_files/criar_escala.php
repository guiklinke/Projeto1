<?php
// A sessão precisa ser iniciada em cada página diferente
$nivel_necessario=0; //Inicializando variável de nível necessário para entrar nesta página
if (!isset($_SESSION)) session_start();
include "../funcoes/conecta_mysql.inc";
$nivel_necessario == 3+1;

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
  // Destrói a sessão por segurança
  session_destroy();
  // Redireciona o visitante de volta pro login
  header("Location: index.php"); exit;
} 


$inicio = filter_input(INPUT_POST, 'inicio', FILTER_SANITIZE_STRING);
$fim = filter_input(INPUT_POST, 'fim', FILTER_SANITIZE_STRING);
$turno = filter_input(INPUT_POST, 'turno', FILTER_SANITIZE_STRING);

$start_date = new DateTime($inicio);
$a = date_format($start_date,'Y:m:d');
$end_date = new DateTime($fim);
$period = new DatePeriod(
	$start_date, // 1st PARAM: start date
	new DateInterval('P1D'), // 2nd PARAM: interval (1 day interval in this case)
	$end_date // 3rd PARAM: end date
);

#Cadastrando a escala
$result_hosp = "INSERT INTO escalas (inicio,fim,turno) VALUES ('$inicio', '$fim', '$turno')";
$resultado_hosp = mysql_query($result_hosp,$conexao1);
$esc_ID = mysql_insert_id($conexao1);

#Cadastrando todos os usuarios existentes na escala
$users_query = "SELECT ID, Setor_ID FROM usuarios";
$users = mysql_query($users_query,$conexao1);
$esc_query = 'INSERT INTO usuarios_escalas (esc_ID) VALUES ';

#E tambem todos os dias para cada usuario
$day_query = 'INSERT INTO usuarios_dias_escalas (esc_ID, dia) VALUES ';

$first = True;
while($row=mysql_fetch_array($users)){
	if (!$first){
		$esc_query .= " , ";
	}
	foreach ($period as $day){
		if (!$first){
			$day_query .= " , ";
		}
		else{
			$first=False;
		}
		$date_string = date_format($day,'Y-m-d');
	    $day_query .= "($esc_ID,'$date_string')";
	}
    $esc_query .= "($esc_ID)";
}



mysql_query($esc_query,$conexao1);

mysql_query($day_query,$conexao1);


if (mysql_affected_rows($conexao1)>0) {
	
	$_SESSION['msg'] = "<p style= color:blue;'>CADASTRADO COM SUCESSO!! </p>";
	header ("Location: escala_criacao.php");
} else {
	$_SESSION['msg'] = "<p style= color:red;'>NÃO CADASTRADO!! $day_query</p>";
	header ("Location: escala_criacao.php");
}


