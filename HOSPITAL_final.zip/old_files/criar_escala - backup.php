<?php
// A sessão precisa ser iniciada em cada página diferente
$nivel_necessario=0; //Inicializando variável de nível necessário para entrar nesta página
if (!isset($_SESSION)) session_start();
include "../funcoes/conecta_mysql.inc";
$nivel_necessario == 3+1;

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
  // Destrói a sessão por segurança
  session_destroy();
  // Redireciona o visitante de volta pro login
  header("Location: index.php"); exit;
} 


$inicio = filter_input(INPUT_POST, 'inicio', FILTER_SANITIZE_STRING);
$fim = filter_input(INPUT_POST, 'fim', FILTER_SANITIZE_STRING);
$turno = filter_input(INPUT_POST, 'turno', FILTER_SANITIZE_STRING);


$result_hosp = "INSERT INTO escalas (inicio,fim,turno) VALUES ('$inicio', '$fim', '$turno')";

#Aqui tambem precisa cadastrar todos os usuarios e todos os dias de cada usuario
$resultado_hosp = mysql_query($result_hosp,$conexao1);

if (mysql_affected_rows($conexao1)>0) {
	
	$_SESSION['msg'] = "<p style= color:blue;'>CADASTRADO COM SUCESSO!! </p>";
	header ("Location: escala_criacao.php");
} else {
	$_SESSION['msg'] = "<p style= color:red;'>NÃO CADASTRADO!!</p> $result_hosp";
	header ("Location: escala_criacao.php");
}


