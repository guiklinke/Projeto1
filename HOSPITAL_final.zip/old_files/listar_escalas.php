<?php
// A sessão precisa ser iniciada em cada página diferente
$nivel_necessario=0; //Inicializando variável de nível necessário para entrar nesta página
if (!isset($_SESSION)) session_start();
include "../funcoes/conecta_mysql.inc";
$nivel_necessario == 3+1;

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
  // Destrói a sessão por segurança
  session_destroy();
  // Redireciona o visitante de volta pro login
  header("Location: index.php"); exit;
} 
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <title> HOSPITAL - Cadastro </title>
    <link rel="stylesheet" type="text/css" href="../sistema/escala/estilo1.css"/>
  <head>
  
  <style>
  
  body {
  background-image: url('logo.png');
  background-repeat: no-repeat;
  background-size: 15% 25%; 
  background-position: top right;
  background-attachment: fixed;
  }
  
  <?php 
  
  $q = "SELECT esc_ID, inicio, fim, turno FROM escalas";
  $escalas= mysql_query($q,$conexao1); 
  ?>
  </style>
   
  
  <body>
    <div class="div1l">
    
     <div class="divtitulol"><span style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:15px; color:#f90;width:400px;position: absolute; margin-left: 150px;margin-top: 10px">Escolha a Escala Desejada</span></div> <!-- fim div-->
    
    <div class="div2l">
    <form method="POST" action="../sistema/listas/listas_escala_tela.php">
      
      <label style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:15px; color:#f90;">Escala: </label>
      <select name="escala" id="escala">
                                        <option value = NULL>Selecione a escala:</option>
            <?php
            while ($m = mysql_fetch_assoc($escalas)) {
              
            ?>

                <option value="<?php echo $m['esc_ID']; //aqui vai o valor a ser guardado no POST?>"><?php echo 'Inicio: ', $m['inicio'], ' Fim: ', $m['fim'], ' Turno: ', $m['turno']; //aqui vai o que vai ser mostrado?></option> 
            <?php
            }
        ?>
        </select><br><br>

        </div> <!-- fim div 2-->



      <div class="divbotaol"><input formaction ="../sistema/listas/listas_escala_tela.php" type="submit" value="ALTERAR" style="position: absolute; margin-left: 100px;margin-top: -8px"> 
      <input formaction ="../sistema/listas/listas_escala_pdf.php" type="submit" value="GERAR PDF" style="position: absolute; margin-left: 250px;margin-top: -8px"> </div> <!-- fim div botao-->
      
      
      </form>
       </div> <!-- fim div 1 l-->

       <?php
        if (isset ($_SESSION['msg'])) { 
        echo $_SESSION['msg'];
        unset ($_SESSION['msg']);
        } 
      ?>

  </body>
</html>