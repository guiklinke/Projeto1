<?php
// A sess�o precisa ser iniciada em cada p�gina diferente
$nivel_necessario=0; //Inicializando vari�vel de n�vel necess�rio para entrar nesta p�gina
if (!isset($_SESSION)) session_start();
$nivel_necessario == 3+1;
// Verifica se n�o h� a vari�vel da sess�o que identifica o usu�rio
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] == $nivel_necessario)) {
	// Destr�i a sess�o por seguran�a
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: index.php"); exit;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
 <html xmlns="http://www.w3.org/1999/xhtml">
  <head>
<meta name="description" content="IE=8; charset=iso-8859-1" />
<meta http-equiv="X-UA-Compatible" content="IE=8; charset=iso-8859-1"/>
<title>Mudar senha</title>
<link rel="stylesheet" href="funcoes/css/style_contspi.css" type="text/css">
<style type="text/css">
body {
	background: none;
}
</style>

<script type='text/javascript'>
String.prototype.trim = function() { return this.replace(/^\s+|\s+$/g, ''); };
</script>

<script type='text/javascript'>
function validar_cpb() {
if(document.alterar_senha.login.value.trim()=="") {
alert("O preenchimento do campo \"Usu�rio\" � obrigat�rio");
return false; // anulando o envio
}
if(document.alterar_senha.senha.value.trim()=="") {
alert("O preenchimento do campo \"Senha atual\" � obrigat�rio");
return false; // anulando o envio
}
 else {
return true; // envia
}
}
</script>



<script type='text/javascript'>
function validar_senha() {
if(document.mudar_senha.senha_nova.value.trim()=="") {
alert("O preenchimento do campo \"Senha nova\" � obrigat�rio");
return false; // anulando o envio
}
if(document.mudar_senha.confirmacao.value.trim()=="") {
alert("O preenchimento do campo \"Confirma��o\" � obrigat�rio");
return false; // anulando o envio
}
if(document.mudar_senha.senha_nova.value!=document.mudar_senha.confirmacao.value) {
alert("Os campos \"Senha nova\" e \"Confirma��o\" est�o com valores diferentes");
return false; // anulando o envio
}
 else {
return true; // envia
}
}
</script>


<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
 </head>
<body>

<?php
header('Content-Type: text/html; charset=ISO-8859-1');

include "funcoes/conecta_mysql.inc";

date_default_timezone_set('America/Sao_Paulo');
?>

<?php
if(!isset($_POST["Login"]))	// solicita o c�digo
{
?>
		<form method="POST" name="alterar_senha" action="alterar_senha.php" onsubmit="return validar_cpb()">
        <br><br>
		<table width="327" border="0" align="center" cellpadding="0" cellspacing="2"  style="color:#666; padding:2em;-webkit-box-shadow: 21px 29px 52px -9px rgba(0,0,0,0.45);
-moz-box-shadow: 21px 29px 52px -9px rgba(0,0,0,0.45);
box-shadow: 21px 29px 52px -9px rgba(0,0,0,0.45); background-color:aliceblue; border: #69c solid 1px;">
        <tr>
        <td><img src="imagens/cadeado.png" width="26" height="20" /></td>
          <td colspan="2"><h2 style="vertical-align:middle;">Altera��o de senha<h2>
</td>
          </tr>
        <tr>
          <td colspan="3"><h3>Entre com os dados de login e senha atuais<h3>
</td>
          </tr>
        <tr>
        <td width="91" >&nbsp;Login&nbsp;</td>
        <td colspan="2"><input type="text" name="Login" style="width:200px; vertical-align:middle; color:#666; border-style:solid; border-width:thin; border-color:#f90; background-color:#fff; height:20px; border-radius:3px;  height:24px; cursor:pointer;"></td>
        </tr>
        <tr>
        <td >&nbsp;Senha&nbsp;</td>
        <td colspan="2"><input  type="password" name="Senha" size="20" style="width:200px; vertical-align:middle; color:#666; border-style:solid; border-width:thin; border-color:#f90; background-color:#fff; height:20px; border-radius:3px;  height:24px; cursor:pointer;"></td>
        </tr>
        <tr height="40">
        <td>&nbsp;</td>
        <td width="175"><input type="submit" value="ok" name="alterar2" /></td>
        <td width="55">&nbsp;</td>
        </tr>
        </table>
		</form>
<?php
}
elseif(!isset($_POST["enviar"]))		// busca os dados do produto
{
	$login=$_POST["Login"];
	$senha=$_POST["Senha"];
	
	$sql = "SELECT * FROM hospital.usuarios WHERE Login='$login' AND Senha='$senha'";
	$res = mysql_query($sql);
	if(mysql_num_rows($res)==0)
		echo "<script type='text/javascript'>
		alert('Usu�rio ou senha inv�lido!!!');
		history.go(-1);
		</script>"; 
	else
	{
		$registro=mysql_fetch_row($res);
		$id=$registro[0];
		$nome=$registro[1];
		$login=$registro[2];
		$senha_atual=$registro[3];

?>
		<form method="POST" name="mudar_senha" action="alterar_senha.php" onsubmit="return validar_senha()">
		<br><br>
        <table width="327" border="0" align="center" cellpadding="0" cellspacing="2" style="color:#666; padding:2em;-webkit-box-shadow: 21px 29px 52px -9px rgba(0,0,0,0.45);
-moz-box-shadow: 21px 29px 52px -9px rgba(0,0,0,0.45);
box-shadow: 21px 29px 52px -9px rgba(0,0,0,0.45); background-color:aliceblue; border: #69c solid 1px;">
        <tr>
        <td><img src="imagens/cadeado.png" width="26" height="20" /></td>
          <td colspan="2"><h2 style="vertical-align:middle;">Altera��o de senha<h2>
</td>
          </tr>
        <tr>
          <td colspan="2"><h3>Entre com os novos dados</h3></td>
          </tr>
        <td>&nbsp;Senha nova&nbsp;</td>
        <td>&nbsp;<input type="password" name="senha_nova" size="20" style="width:200px; vertical-align:middle; color:#666; border-style:solid; border-width:thin; border-color:#f90; background-color:#fff; height:20px; border-radius:3px;  height:24px; cursor:pointer;"></td>
        </tr>
        <tr>
        <td>&nbsp;Cofirma&ccedil;&atilde;o&nbsp;</td>
        <td>&nbsp;<input type="password" name="confirmacao" size="20" style="width:200px; vertical-align:middle; color:#666; border-style:solid; border-width:thin; border-color:#f90; background-color:#fff; height:20px; border-radius:3px;  height:24px; cursor:pointer;"></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr height="40">
          <td>&nbsp;</td>
          <td>
		<input type="hidden" name="ID" value="<?php echo $id;?>">
		<input type="hidden" name="Login" value="<?php echo $login;?>">
		<input type="hidden" name="enviar" value="S">
		<input type="submit" value="Alterar senha" name="alterar">
		<input type="button" value="Voltar" class="doc_input_submit" onClick="location.href='javascript:window.history.go(-1)'" title="Voltar �p�gina anterior" style="color:#900">
          </td>
        </tr>
		</table>
        </form>
<?php
		mysql_close($conexao);
	}
}
else   // alterar a senha
{
	$id=$_POST["ID"];
	$senha_nova=$_POST["senha_nova"];
	$confirmacao=$_POST["confirmacao"];


		$sql = "UPDATE hospital.usuarios SET Senha='$senha_nova' WHERE ID = $id";
		$res = mysql_query($sql);
		if ($res) { echo "<script type='text/javascript'>
			alert('Senha alterada com sucesso!!!');
			
			</script>";}
			
	mysql_close($conexao);
}
?>
</body>
</html>
