﻿<html>
    <head>
    <link rel="stylesheet" type="text/css" href="funcoes/css/style_login.css" />
	<style type="text/css">
        body,td,th {
		font-family: Lato, Calibri, Arial, sans-serif;
		}
		body {
	background-color:#333333;
		}
	</style>
	    <script type='text/javascript'>
        function validar() {
        if(document.form_login.value=="") {
        alert("O preenchimento do campo de Usuário é obrigatório");
        return false;
		}// anulando o envio
        else if(document.form_senha.value=="") {
        alert("O preenchimento do campo de Senha é obrigatório");
        return false; // anulando o envio
        } else {
        return true; // envia
        }
        }
    </script>
	<script type="text/javascript" language="javascript" src="funcoes/js/jquery-1.12.3.min.js"></script>
		<script type="text/javascript">
			$(function(){
			});
		</script>
    <meta charset="utf-8">
    </head>
    <body>
    		<form name="form_login" class="form-2" method="post" action="validacao_usuario.php"  onsubmit="return validar()">
					<table width="520" cellpadding="0" cellspacing="0">
						<tr>
							<td width="130"><img src="imagens/logo.png" width="80" height="60" alt=""/></td>
							<td width="200"><input type="text" name="Login" placeholder="Usuário"></td>
							<td width="100"><input type="password" name="Senha" placeholder="Senha" class="showpassword"></td>
							<td width="50" valign="top" style="padding-top: 20px; font-size: 40px;">
								<input type="submit" name="submit" value="Log in" style="font-size: 12px; height: 22px"></td>
						</tr>
					</table>
				</form>
    </body>
</html>
