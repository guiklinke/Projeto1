<?php
date_default_timezone_set('America/Sao_Paulo');
header('Content-Type: text/html; charset=ISO-8859-1');
error_reporting(0);

# Conecta ao servidor MySQL
include "funcoes/conecta_mysql.inc";

$login = mysql_real_escape_string($_POST['Login']);
$senha = mysql_real_escape_string($_POST['Senha']);

# Valida��o do usu�rio/senha digitados
$sql = "SELECT * FROM hospital.usuarios WHERE (Login = '". $login ."') AND (Senha = '". $senha ."') AND (ativo = 1) LIMIT 1";
$query = mysql_query($sql);


$resultado = mysql_fetch_assoc($query);

if (!isset($_SESSION)) session_start($query);

	$_SESSION['UsuarioID'] = $resultado['ID'];
	$_SESSION['UsuarioNome'] = $resultado['Nome'];
	$_SESSION['Login'] = $resultado['Login'];
	$_SESSION['UsuarioSenha'] = $resultado['Senha'];
	$_SESSION['UsuarioNivel'] = $resultado['Nivel'];




if (mysql_num_rows($query) != 1) {
	echo "<script type='text/javascript'>alert('Usu�rio ou senha inv�lido!');history.go(-1)</script>";
} else {

header("Location: menu.php?sql=".$sql); exit;

}
?>